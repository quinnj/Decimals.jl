// rust_decimal on the corpora in ../corpora, emitting the same TSV shape as the
// Julia harnesses.  Usage:  cargo run --release -- <path-to-bench-dir>
use rust_decimal::Decimal;
use std::hint::black_box;
use std::str::FromStr;
use std::time::Instant;

fn best<F: FnMut() -> u128>(mut f: F, reps: u32) -> u128 {
    let mut b = u128::MAX;
    for _ in 0..reps {
        let t = f();
        if t < b {
            b = t;
        }
    }
    b
}

fn load(dir: &str, name: &str) -> Vec<String> {
    std::fs::read_to_string(format!("{dir}/corpora/{name}"))
        .unwrap_or_else(|e| panic!("{name}: {e}"))
        .lines()
        .map(|s| s.to_string())
        .collect()
}

fn row(group: &str, op: &str, v: f64, unit: &str) {
    println!("{group}\trust_decimal\t{op}\t{v:.6}\t{unit}");
}

fn main() {
    let dir = std::env::args().nth(1).unwrap_or_else(|| ".".into());
    let money = load(&dir, "money.txt");
    let d38 = load(&dir, "d38.txt");
    let n = money.len() as f64;

    let vals: Vec<Decimal> = money.iter().map(|s| Decimal::from_str(s).unwrap()).collect();
    let nz: Vec<Decimal> = vals
        .iter()
        .map(|v| if v.is_zero() { Decimal::ONE } else { *v })
        .collect();

    // --- scalar, money-shaped ---
    let t = best(
        || {
            let t0 = Instant::now();
            for s in &money {
                black_box(Decimal::from_str(black_box(s)).unwrap());
            }
            t0.elapsed().as_nanos()
        },
        200,
    );
    row("scalar", "parse", t as f64 / n, "ns/op");

    let t = best(
        || {
            let t0 = Instant::now();
            for v in &vals {
                black_box(v.to_string());
            }
            t0.elapsed().as_nanos()
        },
        200,
    );
    row("scalar", "format to String", t as f64 / n, "ns/op");

    let t = best(
        || {
            let t0 = Instant::now();
            let mut s = vals[0];
            for v in &vals[1..] {
                s += *v;
            }
            black_box(s);
            t0.elapsed().as_nanos()
        },
        200,
    );
    row("scalar", "add", t as f64 / (n - 1.0), "ns/op");

    let t = best(
        || {
            let t0 = Instant::now();
            let mut s = vals[0] * vals[1];
            for i in 1..vals.len() - 1 {
                s += vals[i] * vals[i + 1];
            }
            black_box(s);
            t0.elapsed().as_nanos()
        },
        200,
    );
    row("scalar", "multiply", t as f64 / (n - 2.0), "ns/op");

    let t = best(
        || {
            let t0 = Instant::now();
            let mut s = nz[0] / nz[1];
            for i in 1..nz.len() - 1 {
                s += nz[i] / nz[i + 1];
            }
            black_box(s);
            t0.elapsed().as_nanos()
        },
        100,
    );
    row("scalar", "divide", t as f64 / (n - 2.0), "ns/op");

    let t = best(
        || {
            let t0 = Instant::now();
            for v in &vals {
                black_box(f64::try_from(*v).unwrap_or(0.0));
            }
            t0.elapsed().as_nanos()
        },
        200,
    );
    row("scalar", "Float64 conversion", t as f64 / n, "ns/op");

    // --- 38 significant digits: beyond rust_decimal's 96-bit mantissa (~28-29
    // digits).  from_str either errors or silently rounds, so report coverage
    // instead of a time.
    let ok38 = d38
        .iter()
        .filter(|s| {
            Decimal::from_str(s)
                .map(|d| d.to_string().trim_start_matches('-').replace('.', "").trim_start_matches('0').len() >= 38)
                .unwrap_or(false)
        })
        .count();
    row("wide", "exact 38-digit values representable (%)", 100.0 * ok38 as f64 / d38.len() as f64, "%");

    // --- parse by digit width ---
    for (label, file) in [
        ("1-4 digits", "band1_4.txt"),
        ("5-9 digits", "band5_9.txt"),
        ("10-18 digits", "band10_18.txt"),
        ("19-38 digits", "band19_38.txt"),
        ("39-76 digits", "band39_76.txt"),
    ] {
        let strs = load(&dir, file);
        // count how many round-trip exactly; only time a band it can actually represent
        let exact = strs
            .iter()
            .filter(|s| {
                Decimal::from_str(s)
                    .map(|d| d.to_string() == s.trim_end_matches(|c| c == '0') || d.to_string() == **s)
                    .unwrap_or(false)
            })
            .count();
        if exact * 100 / strs.len() < 99 {
            row("bands", label, 100.0 * exact as f64 / strs.len() as f64, "unsupported-%exact");
            continue;
        }
        let t = best(
            || {
                let t0 = Instant::now();
                for s in &strs {
                    black_box(Decimal::from_str(black_box(s)).unwrap());
                }
                t0.elapsed().as_nanos()
            },
            200,
        );
        row("bands", label, t as f64 / strs.len() as f64, "ns/op");
    }

    // --- 1M columnar flows ---
    let bigstrs: Vec<String> = money.iter().cycle().take(1_000_000).cloned().collect();
    let bigv: Vec<Decimal> = vals.iter().cycle().take(1_000_000).cloned().collect();

    let t = best(
        || {
            let t0 = Instant::now();
            let out: Vec<Decimal> = bigstrs.iter().map(|s| Decimal::from_str(s).unwrap()).collect();
            black_box(&out);
            t0.elapsed().as_nanos()
        },
        20,
    );
    row("bulk", "parse 1M", t as f64 / 1e6, "ms/1M");

    let t = best(
        || {
            let t0 = Instant::now();
            let mut s = Decimal::ZERO;
            for v in &bigv {
                s += *v;
            }
            black_box(s);
            t0.elapsed().as_nanos()
        },
        20,
    );
    row("bulk", "sum 1M", t as f64 / 1e6, "ms/1M");

    let t = best(
        || {
            let t0 = Instant::now();
            let out: Vec<Decimal> = bigv.iter().map(|v| v * v).collect();
            black_box(&out);
            t0.elapsed().as_nanos()
        },
        20,
    );
    row("bulk", "multiply 1M", t as f64 / 1e6, "ms/1M");
}
