# Ecosystem compatibility gauntlet for Decimal/DecimalValue: run our types
# through the flows a user coming from Arrow/Postgres/CSV would hit, and
# catalog every MethodError, wrong result, semantic surprise, or perf cliff.
using Decimals, Printf, Random
using Decimals: unscaled, scale

const RESULTS = Tuple{String, String, String}[]  # (area, test, outcome)
function trial(f, area, name)
    outcome = try
        r = f()
        "OK: " * first(string(r), 90)
    catch e
        string(typeof(e)) * ": " * first(sprint(showerror, e), 140)
    end
    push!(RESULTS, (area, name, outcome))
    return nothing
end

rng = Xoshiro(123)
d(s) = Decimal{18,2}(s)
v = [d("1.25"), d("2.50"), d("-0.75"), d("10.00"), d("3.33")]
dv = DecimalValue{Int64}(125, 2)

# ---- Base numeric surface ----
trial(() -> d("2.0")^2, "base", "x^2 literal_pow")
trial(() -> d("2.0")^3, "base", "x^3")
trial(() -> d("2.0")^-1, "base", "x^-1")
trial(() -> sqrt(d("4.0")), "base", "sqrt")
trial(() -> exp(d("1.0")), "base", "exp")
trial(() -> log(d("2.0")), "base", "log")
trial(() -> abs2(d("1.5")), "base", "abs2")
trial(() -> sign(d("-1.5")), "base", "sign")
trial(() -> copysign(d("1.5"), -1), "base", "copysign")
trial(() -> flipsign(d("1.5"), -1), "base", "flipsign")
trial(() -> muladd(d("1.5"), d("2.0"), d("0.5")), "base", "muladd")
trial(() -> mod1(d("5.5"), d("2.0")), "base", "mod1")
trial(() -> clamp(d("5.5"), d("1.0"), d("2.0")), "base", "clamp")
trial(() -> hypot(d("3.0"), d("4.0")), "base", "hypot")
trial(() -> isapprox(d("1.00"), d("1.01")), "base", "isapprox")
trial(() -> isapprox(d("1.00"), 1.0), "base", "isapprox vs float")
trial(() -> float(d("1.25")), "base", "float(x)")
trial(() -> float(Decimal64{2}), "base", "float(::Type)")
trial(() -> float([d("1.25")]), "base", "float(Vector)")
trial(() -> big(d("1.25")), "base", "big(x)")
trial(() -> oneunit(Decimal64{2}), "base", "oneunit")
trial(() -> Decimal64{2}(2), "base", "T(2) construct")
trial(() -> widen(d("1.5")), "base", "widen(value)")
trial(() -> string(Ref(d("1.5"))), "base", "show in container")
trial(() -> (io = IOBuffer(); @printf(io, "%.3f", d("1.25")); String(take!(io))), "base", "@printf %f")
trial(() -> (io = IOBuffer(); @printf(io, "%d", d("1.00")); String(take!(io))), "base", "@printf %d")
trial(() -> rationalize(d("1.25")), "base", "rationalize")
trial(() -> trunc(Int, dv), "base", "trunc DV")

# ---- ranges / iteration ----
trial(() -> collect(d("0.10"):d("0.10"):d("0.50")), "ranges", "a:s:b")
trial(() -> collect(d("1.00"):d("1.00"):d("3.00"))[2], "ranges", "a:s:b index")
trial(() -> length(d("0.10"):d("0.10"):d("1000.00")), "ranges", "range length")
trial(() -> collect(range(d("0.00"), d("1.00"), length=5)), "ranges", "range(len)")
trial(() -> sum(d("0.01"):d("0.01"):d("1.00")), "ranges", "sum of range")

# ---- random ----
trial(() -> rand(rng, Decimal64{2}), "random", "rand(T)")
trial(() -> rand(rng, v), "random", "rand from vector")
trial(() -> shuffle(rng, v), "random", "shuffle")

# ---- sorting / searching / collections ----
trial(() -> searchsortedfirst(sort(v), d("2.00")), "collections", "searchsorted")
trial(() -> extrema(v), "collections", "extrema")
trial(() -> findmax(v), "collections", "findmax")
trial(() -> unique([d("1.20"), Decimal{9,1}("1.2")]), "collections", "unique cross-type")
trial(() -> Set(v) == Set(v), "collections", "Set")
trial(() -> maximum(abs, v), "collections", "maximum(abs)")
trial(() -> cumsum(v), "collections", "cumsum")
trial(() -> cumsum(v)[end], "collections", "cumsum last")
trial(() -> accumulate(+, v), "collections", "accumulate(+)")
trial(() -> prod(v[1:3]), "collections", "prod (type growth)")
trial(() -> diff(v), "collections", "diff")

# ---- Statistics stdlib ----
using Statistics
trial(() -> mean(v), "statistics", "mean")
trial(() -> typeof(mean(v)), "statistics", "mean type")
trial(() -> median(v), "statistics", "median")
trial(() -> var(v), "statistics", "var")
trial(() -> std(v), "statistics", "std")
trial(() -> quantile(v, 0.5), "statistics", "quantile")
trial(() -> cor([float(x) for x in v], float.(v)), "statistics", "cor floats(ref)")
trial(() -> middle(d("1.0"), d("2.0")), "statistics", "middle")

# ---- LinearAlgebra ----
using LinearAlgebra
A = [d("1.00") d("2.00"); d("3.00") d("4.00")]
b2 = [d("1.00"), d("2.00")]
trial(() -> A * b2, "linalg", "matvec")
trial(() -> typeof(A * A), "linalg", "matmul type")
trial(() -> A + A, "linalg", "mat add")
trial(() -> A', "linalg", "adjoint")
trial(() -> dot(b2, b2), "linalg", "dot")
trial(() -> norm(b2), "linalg", "norm(2)")
trial(() -> norm(b2, 1), "linalg", "norm(1)")
trial(() -> norm(b2, Inf), "linalg", "norm(Inf)")
trial(() -> det(A), "linalg", "det")
trial(() -> lu(A), "linalg", "lu")
trial(() -> A \ b2, "linalg", "solve \\")
trial(() -> inv(A), "linalg", "inv")
trial(() -> tr(A), "linalg", "tr")
trial(() -> Symmetric(A), "linalg", "Symmetric wrap")
trial(() -> diagm(b2), "linalg", "diagm")
trial(() -> float(A) \ float(b2), "linalg", "float-solve (rec path)")

# ---- GenericLinearAlgebra ----
using GenericLinearAlgebra
trial(() -> GenericLinearAlgebra.svdvals!(float.(A)), "linalg", "GLA svdvals on float")
trial(() -> eigvals(float.(A)), "linalg", "eigvals on float(A)")

# ---- StaticArrays ----
using StaticArrays
trial(() -> SVector(d("1.0"), d("2.0")) + SVector(d("0.5"), d("0.5")), "staticarrays", "SVector add")
trial(() -> SMatrix{2,2}(A) * SVector(d("1.0"), d("2.0")), "staticarrays", "SMatrix mul")

# ---- DataFrames ----
using DataFrames
df = DataFrame(k=[1, 1, 2, 2, 3], x=[d("1.25"), d("2.50"), d("-0.75"), d("10.00"), d("3.33")])
trial(() -> combine(groupby(df, :k), :x => sum), "dataframes", "groupby sum")
trial(() -> combine(groupby(df, :k), :x => mean), "dataframes", "groupby mean")
trial(() -> sort(df, :x), "dataframes", "sort by decimal")
trial(() -> innerjoin(df, df, on=:x, makeunique=true), "dataframes", "join on decimal")
trial(() -> describe(df), "dataframes", "describe")
trial(() -> df.x .* 2, "dataframes", "column scale")

# ---- StatsBase ----
using StatsBase
trial(() -> StatsBase.countmap(v), "statsbase", "countmap")
trial(() -> StatsBase.ecdf(float.(v)), "statsbase", "ecdf floats")
trial(() -> StatsBase.summarystats(v), "statsbase", "summarystats")
trial(() -> StatsBase.mode(v), "statsbase", "mode")

# ---- Unitful ----
using Unitful
trial(() -> d("1.25") * u"m", "unitful", "attach unit")
trial(() -> (d("1.25")u"m" + d("0.25")u"m"), "unitful", "unit add")
trial(() -> d("1.25")u"m" * d("2.00")u"m", "unitful", "unit mul (m^2)")
trial(() -> d("1.25")u"m" / d("0.25")u"s", "unitful", "unit div")
trial(() -> uconvert(u"cm", d("1.25")u"m"), "unitful", "uconvert")
trial(() -> uconvert(u"ft", d("1.00")u"m"), "unitful", "uconvert irrational factor")
trial(() -> sum([d("1.25")u"m", d("0.75")u"m"]), "unitful", "sum of quantities")

# ---- ForwardDiff ----
using ForwardDiff
trial(() -> ForwardDiff.derivative(x -> x * x, d("2.0")), "autodiff", "derivative x^2")
trial(() -> ForwardDiff.derivative(x -> x * d("3.0") + d("1.0"), d("2.0")), "autodiff", "derivative affine")
trial(() -> ForwardDiff.derivative(x -> x * x, float(d("2.0"))), "autodiff", "derivative on float (rec)")

# ---- JuMP (model construction; no solver in env) ----
using JuMP
trial(function ()
    m = Model()
    @variable(m, 0 <= x <= 10)
    @objective(m, Max, d("2.50") * x)
    @constraint(m, c1, d("1.25") * x <= d("5.00"))
    (objective_function(m), constraint_object(m[:c1]).func)
end, "jump", "decimal coefficients build")
trial(function ()
    m = Model()
    @variable(m, y[1:2] >= 0)
    @constraint(m, c2, sum(d("0.50") * y[i] for i in 1:2) <= d("3.00"))
    constraint_object(m[:c2]).func
end, "jump", "decimal in sum expr")

# ---- OrdinaryDiffEq ----
using OrdinaryDiffEqTsit5
trial(function ()
    prob = ODEProblem((u, p, t) -> u, d("1.00"), (d("0.00"), d("1.00")))
    OrdinaryDiffEqTsit5.solve(prob, Tsit5()).u[end]
end, "diffeq", "ODE decimal u0/tspan")
trial(function ()
    prob = ODEProblem((u, p, t) -> u, float(d("1.00")), (0.0, 1.0))
    OrdinaryDiffEqTsit5.solve(prob, Tsit5()).u[end]
end, "diffeq", "ODE float (rec path)")

# ---- JSON ----
using JSON
trial(() -> JSON.json(Dict("amount" => d("1.25"))), "json", "JSON.json")
trial(() -> JSON.json([dv]), "json", "JSON.json DecimalValue")

# CSV.jl pins Parsers 2.x, so it cannot be resolved into this Parsers 3
# environment and has no trials here.

# ---- accuracy landmines ----
trial(() -> det(A) == -2, "landmines", "det exactness (true = -2)")
trial(() -> A \ b2 == float(A) \ float(b2), "landmines", "solve matches float")
trial(() -> typeof(lu(A)), "landmines", "lu routes to float")
trial(() -> cholesky([d("4.0") d("2.0"); d("2.0") d("3.0")]), "landmines", "cholesky routes")
trial(() -> eigvals(A), "landmines", "eigvals on decimal")
A9 = [Decimal{18,9}("1.000000001") Decimal{18,9}("2.0"); Decimal{18,9}("3.0") Decimal{18,9}("4.0")]
trial(() -> det(A9), "landmines", "det at scale 9")
trial(() -> det(map(x -> Rational{BigInt}(x), A)), "landmines", "det via Rational (exact)")
trial(() -> det(float(A)), "landmines", "det via float")
trial(() -> mean(v) == (sum(v) / 5), "landmines", "mean == sum/n")
trial(() -> sum(v) / 5, "landmines", "sum/n value+type")
using Chairmarks
B1 = [reinterpret(Decimal64{2}, rand(rng, -10^10:10^10)) for _ in 1:100_000]
trial(() -> string(round(1e3 * (@b sort($(copy(B1))) seconds=0.5).time, digits=2)) * " ms sort 100k", "perf", "sort 100k")
Af = [reinterpret(Decimal64{2}, rand(rng, -10^8:10^8)) for _ in 1:40_000]
M1 = reshape(Af[1:2500], 50, 50)
trial(() -> string(round(1e6 * (@b $M1 * $M1 seconds=0.5).time, digits=1)) * " us matmul 50x50", "perf", "matmul 50x50")
Mf = float(M1)
trial(() -> string(round(1e6 * (@b $Mf * $Mf seconds=0.5).time, digits=1)) * " us matmul 50x50 float", "perf", "matmul float ref")
trial(() -> string(round(1e6 * (@b mean($B1) seconds=0.5).time, digits=1)) * " us mean 100k", "perf", "mean 100k")
trial(() -> string(round(1e6 * (@b median($B1) seconds=0.5).time, digits=1)) * " us median 100k", "perf", "median 100k")
trial(() -> string(round(1e6 * (@b median($(float(B1))) seconds=0.5).time, digits=1)) * " us median float ref", "perf", "median float ref")

# ---- printout ----
println("\n", "="^100)
lastarea = ""
for (area, name, outcome) in RESULTS
    global lastarea
    if area != lastarea
        println("\n== ", area, " ==")
        lastarea = area
    end
    ok = startswith(outcome, "OK")
    @printf("  %-28s %s %s\n", name, ok ? "✓" : "✗", outcome)
end
nbad = count(r -> !startswith(r[3], "OK"), RESULTS)
println("\n", length(RESULTS), " trials, ", nbad, " failures")
