# Cliff-hunting sweep: probe tier boundaries, slow paths, and semantic edges
# for unexpected performance behavior. Run on a quiet machine.
using Chairmarks, Printf, Random
using Decimals, Parsers
using Decimals: Int256, UInt256
using Decimals: unscaled, scale, writedecimal!
import DecFP

rng = Xoshiro(7001)
ns(b) = 1e9 * b.time
row(label, t) = @printf("  %-46s %9.2f ns/op\n", label, t)

corpus(f, n=500) = [f() for _ in 1:n]

function bench_map(f, xs; seconds=0.5)
    b = @b map(f, xs) seconds=seconds
    return ns(b) / length(xs)
end

println("== 1. parse cost vs digit count (int.2frac form) ==")
for nd in (1, 4, 7, 8, 12, 14, 15, 16, 17, 18, 19, 20, 24, 30, 36, 38, 39, 45, 60, 76)
    intn = max(nd - 2, 1)
    strs = corpus(() -> String(rand(rng, UInt8('1'):UInt8('9'), 1)) *
                        String(rand(rng, UInt8('0'):UInt8('9'), intn - 1)) * "." *
                        String(rand(rng, UInt8('0'):UInt8('9'), 2)))
    DT = nd <= 16 ? Decimal{18,2,Int64} : nd <= 36 ? Decimal{38,2,Int128} : Decimal{76,2,Int256}
    t = bench_map(s -> Parsers.parse(DT, s), strs)
    tdec = nd <= 14 ? bench_map(s -> Base.parse(DecFP.Dec64, s), strs) :
                      bench_map(s -> Base.parse(DecFP.Dec128, s), strs)
    @printf("  %2d digits -> %-22s %7.2f ns   (DecFP %7.2f)\n", nd, DT, t, tdec)
end

println("\n== 2. parse special shapes ==")
zstrs = corpus(() -> "0"^25 * string(rand(rng, 1:999)) * ".25")
row("25 leading zeros", bench_map(s -> Parsers.parse(Decimal64{2}, s), zstrs))
wstrs = corpus(() -> "   " * string(rand(rng, 1:10^6)) * ".25   ")
row("whitespace-padded", bench_map(s -> Parsers.parse(Decimal64{2}, s), wstrs))
estrs = corpus(() -> string(rand(rng, 1:10^6)) * "e-" * string(rand(rng, 1:4)))
row("exponent form", bench_map(s -> Parsers.parse(Decimal64{6}, s), estrs))
cstrs = corpus(() -> replace(string(rand(rng, 1:10^6) / 100), "." => ","))
row("decimal=','", bench_map(s -> Parsers.parse(Decimal64{2}, s, decimal=','), cstrs))
badshort = corpus(() -> String(rand(rng, UInt8('a'):UInt8('z'), 8)))
row("invalid short (tryparse)", bench_map(s -> Parsers.tryparse(Decimal64{2}, s), badshort))
badlong = corpus(() -> String(rand(rng, UInt8('a'):UInt8('z'), 200)))
row("invalid long 200B (tryparse)", bench_map(s -> Parsers.tryparse(Decimal64{2}, s), badlong))
badnum = corpus(() -> string(rand(rng, 1:10^6)) * ".1.2")
row("almost-valid 1.1.2 (tryparse)", bench_map(s -> Parsers.tryparse(Decimal64{2}, s), badnum))
hugestr = ["1" * "0"^999 for _ in 1:50]
row("1000-digit overflow (tryparse)", bench_map(s -> Parsers.tryparse(Decimal64{2}, s), hugestr))
hugefrac = ["0." * "9"^999 for _ in 1:50]
row("1000-frac-digit round (parse)", bench_map(s -> Parsers.parse(Decimal64{2}, s), hugefrac))
bigexp = corpus(() -> "1.5e" * string(rand(rng, 100000:999999)))
row("huge exponent (tryparse)", bench_map(s -> Parsers.tryparse(Decimal64{2}, s), bigexp))

println("\n== 3. add/sub shape grid (fold over 500 pairs) ==")
mk(DT, digs) = [reinterpret(DT, rand(rng, -10^digs:10^digs) % Decimals._storage(DT)) for _ in 1:500]
function foldop(op, a, b)
    s = op(a[1], b[1])
    @inbounds for i in 2:length(a)
        s = op(a[i], b[i])
    end
    return s
end
a64 = mk(Decimal64{2}, 15); b64 = mk(Decimal64{2}, 15)
row("same type D64{2}+D64{2}", ns(@b foldop(+, a64, b64) seconds=0.5) / 500)
b64p = mk(Decimal{15,2,Int64}, 12)
row("same S, diff P (D{18,2}+D{15,2})", ns(@b foldop(+, a64, b64p) seconds=0.5) / 500)
b64s = mk(Decimal{18,4,Int64}, 13)
row("mixed S (D{18,2}+D{18,4})", ns(@b foldop(+, a64, b64s) seconds=0.5) / 500)
b128 = mk(Decimal{38,9,Int128}, 20)
row("cross tier (D64{2}+D128{9})", ns(@b foldop(+, a64, b128) seconds=0.5) / 500)
b256 = mk(Decimal{76,9,Int256}, 30)
row("cross tier (D64{2}+D256{9})", ns(@b foldop(+, a64, b256) seconds=0.5) / 500)
hi64 = [reinterpret(Decimal64{2}, (10^18 - 1) - rand(rng, 0:10^6)) for _ in 1:500]
lo64 = [reinterpret(Decimal64{2}, -rand(rng, 0:10^6)) for _ in 1:500]
row("near-max magnitudes (no overflow)", ns(@b foldop(+, hi64, lo64) seconds=0.5) / 500)
a32 = mk(Decimal32{2}, 6); b32 = mk(Decimal32{2}, 6)
row("D32{2}+D32{2}", ns(@b foldop(+, a32, b32) seconds=0.5) / 500)
a256 = mk(Decimal256{9}, 30); b256b = mk(Decimal256{9}, 30)
row("D256{9}+D256{9}", ns(@b foldop(+, a256, b256b) seconds=0.5) / 500)

println("\n== 4. multiply tier grid ==")
row("D32*D32", ns(@b foldop(*, a32, b32) seconds=0.5) / 500)
row("D64*D64", ns(@b foldop(*, a64, b64) seconds=0.5) / 500)
row("D64*D128", ns(@b foldop(*, a64, b128) seconds=0.5) / 500)
a128 = mk(Decimal{38,9,Int128}, 14); b128b = mk(Decimal{38,9,Int128}, 14)
row("D128*D128 (small values)", ns(@b foldop(*, a128, b128b) seconds=0.5) / 500)
a128w = mk(Decimal{38,9,Int128}, 30); b128w = mk(Decimal{38,4,Int128}, 30)
row("D128*D128 (30-digit values)", ns(@b foldop(*, a128w, b128w) seconds=0.5) / 500)
a256s = mk(Decimal{76,9,Int256}, 30); b256s = mk(Decimal{76,4,Int256}, 30)
row("D256*D256", ns(@b foldop(*, a256s, b256s) seconds=0.5) / 500)
ints = rand(rng, 1:1000, 500)
row("D64*Int (scale-preserving)", ns(@b foldop(*, a64, ints) seconds=0.5) / 500)

println("\n== 5. divide sweeps ==")
for dd in (1, 5, 9, 10, 15, 18, 19, 25, 38)
    dv = [reinterpret(Decimal{38,4,Int128}, (Int128(10)^(dd-1) + rand(rng, 0:Int128(10)^(dd-1)*8)) *
          rand(rng, (-1, 1))) for _ in 1:500]
    nm = mk(Decimal{38,4,Int128}, 15)
    t = ns(@b foldop(/, nm, dv) seconds=0.5) / 500
    @printf("  divisor %2d digits:            %9.2f ns/op\n", dd, t)
end
nm64 = mk(Decimal64{2}, 8)
dv64 = [reinterpret(Decimal64{2}, rand(rng, 1:10^8) * rand(rng, (-1, 1))) for _ in 1:500]
row("D64{2}/D64{2} small (u64 tier)", ns(@b foldop(/, nm64, dv64) seconds=0.5) / 500)
nmbig = [reinterpret(Decimal64{2}, rand(rng, 10^16:10^18-1)) for _ in 1:500]
row("D64{2}/D64{2} big dividend", ns(@b foldop(/, nmbig, dv64) seconds=0.5) / 500)
dvdec = [Base.parse(DecFP.Dec64, string(x)) for x in rand(rng, 1:10^8, 500)]
nmdec = [Base.parse(DecFP.Dec64, string(x / 100)) for x in rand(rng, 1:10^10, 500)]
row("DecFP Dec64/Dec64 (reference)", ns(@b foldop(/, nmdec, dvdec) seconds=0.5) / 500)

println("\n== 6. rescale/round sweeps ==")
# literal target types: interpolating the scale as a runtime type parameter
# would benchmark dynamic dispatch, not the library
for (k, expr) in ((1, :(Decimal{38,37,Int128})), (2, :(Decimal{38,36,Int128})),
                  (5, :(Decimal{38,33,Int128})), (9, :(Decimal{38,29,Int128})),
                  (10, :(Decimal{38,28,Int128})), (18, :(Decimal{38,20,Int128})),
                  (19, :(Decimal{38,19,Int128})), (30, :(Decimal{38,8,Int128})),
                  (38, :(Decimal{38,0,Int128})))
    src = mk(Decimal{38,38,Int128}, 30)
    t = @eval ns(@b map(x -> rescale($expr, x), $src) seconds=0.3) / 500
    @printf("  rescale down by %2d:           %9.2f ns/op\n", k, t)
end
modes = (RoundNearest, RoundNearestTiesAway, RoundToZero, RoundDown, RoundUp)
src = mk(Decimal{38,20,Int128}, 30)
for mode in modes
    t = ns(@b map(x -> rescale(Decimal{38,4,Int128}, x, $mode), $src) seconds=0.3) / 500
    @printf("  rescale mode %-22s %9.2f ns/op\n", mode, t)
end

println("\n== 7. Float64 conversion cliffs ==")
small = mk(Decimal64{2}, 12)
row("Float64(D64{2}) u<2^53 fast", bench_map(Float64, small))
big64 = [reinterpret(Decimal64{2}, rand(rng, 10^16:10^18-1)) for _ in 1:500]
row("Float64(D64{2}) u>2^53", bench_map(Float64, big64))
d128small = mk(Decimal{38,9,Int128}, 14)
row("Float64(D128{9}) small", bench_map(Float64, d128small))
d128big = mk(Decimal{38,9,Int128}, 30)
row("Float64(D128{9}) 30-digit", bench_map(Float64, d128big))
d256big = mk(Decimal{76,40,Int256}, 60)
row("Float64(D256{40}) 60-digit", bench_map(Float64, d256big))
s30 = [reinterpret(Decimal{38,30,Int128}, rand(rng, Int128(10)^20:Int128(10)^25)) for _ in 1:500]
row("Float64(D{38,30}) S>22", bench_map(Float64, s30))
alloc1 = @allocated map(Float64, d128big)
@printf("  allocations for 500 slow-path conversions: %d bytes\n", alloc1)
decf = [Base.parse(DecFP.Dec128, string(big(rand(rng, 10^15:10^18)) * 10^12)) for _ in 1:500]
row("DecFP Float64(Dec128) reference", bench_map(Float64, decf))

println("\n== 8. hash / dict / sort ==")
plain = mk(Decimal64{2}, 12)
row("hash(D64{2}) random", bench_map(hash, plain))
tz = [reinterpret(Decimal{38,30,Int128}, Int128(rand(rng, 1:999)) * Int128(10)^28) for _ in 1:500]
row("hash(D{38,30}) 28 trailing zeros", bench_map(hash, tz))
tz256 = [reinterpret(Decimal{76,70,Int256}, Int256(rand(rng, 1:999)) * Int256(10)^68) for _ in 1:500]
row("hash(D{76,70}) 68 trailing zeros", bench_map(hash, tz256))
frac = [reinterpret(Decimal64{9}, rand(rng, 1:10^15) * 10 + 3) for _ in 1:500]
row("hash(D64{9}) fractional", bench_map(hash, frac))
@printf("  hash alloc (500 fractional): %d bytes\n", @allocated map(hash, frac))
row("Dict insert+lookup D64{2}", ns(@b (d = Dict{Decimal64{2},Int}(); for (i, x) in enumerate($plain); d[x] = i; end; s = 0; for x in $plain; s += d[x]; end; s) seconds=0.5) / 1000)
mixv = vcat(mk(Decimal{18,2,Int64}, 12), mk(Decimal{18,2,Int64}, 8))
row("sort! same-scale 1000", ns(@b sort!(copy($mixv)) seconds=0.5) / 1000)
dv2 = [DecimalValue{Int128}(rand(rng, -10^12:10^12), rand(rng, 0:15)) for _ in 1:1000]
row("sort! DecimalValue mixed-scale 1000", ns(@b sort!(copy($dv2)) seconds=0.5) / 1000)

println("\n== 9. format sweeps ==")
for nd in (4, 9, 18, 19, 38, 76)
    T = nd <= 9 ? Int32 : nd <= 18 ? Int64 : nd <= 38 ? Int128 : Int256
    P = nd <= 9 ? 9 : nd <= 18 ? 18 : nd <= 38 ? 38 : 76
    vals = [reinterpret(Decimal{P,2,T}, T(rand(rng, big(10)^(nd-1):big(10)^nd - 1) % big(2)^(8*sizeof(T)-1))) for _ in 1:500]
    t = bench_map(string, vals)
    @printf("  string() %2d digits:           %9.2f ns/op\n", nd, t)
end
vbig = DecimalValue{Int64}(5, 1000)
row("string(DecimalValue scale 1000)", ns(@b string($vbig) seconds=0.3))

println("\n== 10. columnar / broadcast ==")
N = 1_000_000
ca = [reinterpret(Decimal64{2}, rand(rng, -10^15:10^15)) for _ in 1:N]
cb = [reinterpret(Decimal64{2}, rand(rng, -10^15:10^15)) for _ in 1:N]
@printf("  bc add 1M same-type:          %9.3f ms\n", 1e3 * (@b $ca .+ $cb seconds=1).time)
@printf("  bc mul 1M same-type:          %9.3f ms\n", 1e3 * (@b $ca .* $cb seconds=1).time)
cmix = [reinterpret(Decimal{18,3,Int64}, rand(rng, -10^15:10^15)) for _ in 1:N]
@printf("  bc add 1M MIXED SCALE:        %9.3f ms\n", 1e3 * (@b $ca .+ $cmix seconds=1).time)
c128 = [reinterpret(Decimal{38,9,Int128}, Int128(rand(rng, -10^18:10^18))) for _ in 1:N]
c128b = [reinterpret(Decimal{38,9,Int128}, Int128(rand(rng, -10^18:10^18))) for _ in 1:N]
@printf("  bc add 1M D128 (generic):     %9.3f ms\n", 1e3 * (@b $c128 .+ $c128b seconds=1).time)
@printf("  bc mul 1M D128 (generic):     %9.3f ms\n", 1e3 * (@b $c128 .* $c128b seconds=1).time)
@printf("  sum 1M D64:                   %9.3f ms\n", 1e3 * (@b sum($ca) seconds=1).time)
@printf("  sum 1M D128:                  %9.3f ms\n", 1e3 * (@b sum($c128) seconds=1).time)
c256 = [reinterpret(Decimal256{9}, Int256(rand(rng, -10^18:10^18))) for _ in 1:N]
@printf("  sum 1M D256:                  %9.3f ms\n", 1e3 * (@b sum($c256) seconds=1).time)
@printf("  count(a .> b) 1M:             %9.3f ms\n", 1e3 * (@b count(i -> $ca[i] > $cb[i], 1:N) seconds=1).time)
@printf("  Float64.(1M D64):             %9.3f ms\n", 1e3 * (@b Float64.($ca) seconds=1).time)

println("\n== 11. allocation audit (typed calls; should all be 0) ==")
# Closures over non-const globals box their captures and report phantom
# allocations, so every audit below goes through a typed-argument function.
h_add(x, y) = @allocated x + y
h_mul(x, y) = @allocated x * y
h_div(x, y) = @allocated x / y
h_res(x) = @allocated rescale(Decimal{38,2,Int128}, x)
h_rnd(x) = @allocated round(x, digits=2)
h_hash(x) = @allocated hash(x)
h_dr(x, y) = @allocated divrem(x, y)
h_fld(x, y) = @allocated fld(x, y)
h_f64(x) = @allocated Float64(x)
h_int(x) = @allocated round(Int, x)
x64 = a64[1]; y64 = b64[1]; x128 = a128w[1]; y128 = b128w[1]
x256 = a256s[1]; y256 = b256s[1]; xmix = b64s[1]; xdv = dv2[1]; ydv = dv2[2]
audits = [
    ("add64", h_add(x64, y64)), ("addmix", h_add(x64, xmix)),
    ("add256", h_add(x256, y256)), ("mul128", h_mul(x128, y128)),
    ("mul256", h_mul(x256, y256)), ("div128", h_div(x128, y128)),
    ("div256", h_div(x256, y256)), ("dv add", h_add(xdv, ydv)),
    ("dv mul", h_mul(xdv, ydv)), ("dv div", h_div(xdv, ydv)),
    ("rescale", h_res(x128)), ("round", h_rnd(x128)),
    ("cmp mixed", @allocated(x64 < x128)),
    ("hash64", h_hash(x64)), ("hash256", h_hash(x256)),
    ("divrem", h_dr(x128, y128)), ("fld", h_fld(x64, y64)),
    ("f64 slow", h_f64(x128)), ("int conv", h_int(x64))]
anybad = false
for (lbl, a) in audits
    if a > 0
        @printf("  ALLOC %-40s %d bytes\n", lbl, a)
        global anybad = true
    end
end
anybad || println("  all zero-alloc")
println("\nsweep done")
