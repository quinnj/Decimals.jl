# Registered Decimals 0.5.1 (BigInt-backed) vs Decimals 1.0 (fixed-point) on an
# identical set of operations over identical input corpora.
#
# The two releases share a UUID, so they can never coexist in one environment.
# This one file therefore runs unchanged in both environments and branches on
# which API is present, keeping the timing loops themselves identical code.
#
#   julia --startup-file=no --project=<old-env> bench/oldvsnew.jl old > results/oldvsnew-old.tsv
#   julia --startup-file=no --project=<new-env> bench/oldvsnew.jl new > results/oldvsnew-new.tsv
#
# Every scalar figure is the Chairmarks minimum over a 1000-element corpus,
# divided by 1000 — single ops are far below timer resolution.
using Chairmarks, Printf, Decimals

const NEW = isdefined(Decimals, :Decimal64)
const LABEL = length(ARGS) >= 1 ? ARGS[1] : (NEW ? "new" : "old")
const CORPORA = joinpath(@__DIR__, "corpora")

readcorpus(name) = readlines(joinpath(CORPORA, name))

const MONEY = readcorpus("money.txt")
const D18 = readcorpus("d18.txt")
const D38 = readcorpus("d38.txt")
const N = length(MONEY)

if NEW
    @eval using Parsers                    # 1.0: parse/tryparse come from the Parsers extension
    const T64 = Decimal64{2}                # Decimal{18,2,Int64}
    const T18 = Decimal{18,3,Int64}
    const T38 = Decimal{38,4,Int128}
    pmoney(s) = Base.parse(T64, s)
    p18(s) = Base.parse(T18, s)
    p38(s) = Base.parse(T38, s)
    fromfloat(x::Float64) = T64(x)
    fromint(i::Int) = T64(i)
else
    pmoney(s) = Base.parse(Decimal, s)
    p18(s) = Base.parse(Decimal, s)
    p38(s) = Base.parse(Decimal, s)
    fromfloat(x::Float64) = Decimal(x)
    fromint(i::Int) = Decimal(i)
end

const VALS = map(pmoney, MONEY)
const NZ = map(x -> iszero(x) ? oneunit(x) : x, VALS)
const FLOATS = map(s -> Base.parse(Float64, s), MONEY)
const INTS = [i * 37 - 18000 for i in 1:N]

# folds keep the data dependency real and avoid allocating a result vector
addfold(v) = (s = v[1]; @inbounds for i in 2:length(v); s += v[i]; end; s)
subfold(v) = (s = v[1]; @inbounds for i in 2:length(v); s -= v[i]; end; s)
mulfold(v) = (s = v[1] * v[2]; @inbounds for i in 2:length(v)-1; s += v[i] * v[i+1]; end; s)
divfold(v) = (s = v[1] / v[2]; @inbounds for i in 2:length(v)-1; s += v[i] / v[i+1]; end; s)
ltfold(v) = (c = 0; @inbounds for i in 1:length(v)-1; c += v[i] < v[i+1]; end; c)
# mixed-type comparison: `decimal < float` is the shape that shows up in filters
# and thresholds, and is the one place a decimal type can quietly fall back to a
# promotion through arbitrary precision
ltfloatfold(v, f) = (c = 0; @inbounds for i in 1:length(v); c += v[i] < f[i]; end; c)
eqfold(v) = (c = 0; @inbounds for i in 1:length(v)-1; c += v[i] == v[i+1]; end; c)
hashfold(v) = (h = UInt(0); @inbounds for x in v; h ⊻= hash(x); end; h)

results = Tuple{String,String,String,Float64,String,Float64}[]

function record(group, op, b, unit; per=N)
    v = unit == "ns/op" ? 1e9 * b.time / per : 1e3 * b.time
    bytes = b.bytes / per
    push!(results, (LABEL, group, op, v, unit, bytes))
    @printf(stderr, "  %-22s %12.2f %-6s  %10.1f B/op\n", op, v, unit, bytes)
    return nothing
end

@info "$LABEL: Decimals v$(pkgversion(Decimals)), julia $(VERSION), NEW=$NEW"

println(stderr, "== scalar ==")
record("scalar", "parse money", (@b map(pmoney, MONEY) seconds=1), "ns/op")
record("scalar", "parse 18-digit", (@b map(p18, D18) seconds=1), "ns/op")
record("scalar", "parse 38-digit", (@b map(p38, D38) seconds=1), "ns/op")
record("scalar", "from Float64", (@b map(fromfloat, FLOATS) seconds=1), "ns/op")
record("scalar", "from Int", (@b map(fromint, INTS) seconds=1), "ns/op")
record("scalar", "add", (@b addfold(VALS) seconds=1), "ns/op"; per=N - 1)
record("scalar", "subtract", (@b subfold(VALS) seconds=1), "ns/op"; per=N - 1)
record("scalar", "multiply", (@b mulfold(VALS) seconds=1), "ns/op"; per=N - 2)
record("scalar", "divide", (@b divfold(NZ) seconds=2), "ns/op"; per=N - 2)
record("scalar", "less-than", (@b ltfold(VALS) seconds=1), "ns/op"; per=N - 1)
record("scalar", "compare to Float64", (@b ltfloatfold(VALS, FLOATS) seconds=1), "ns/op")
record("scalar", "equality", (@b eqfold(VALS) seconds=1), "ns/op"; per=N - 1)
record("scalar", "hash", (@b hashfold(VALS) seconds=1), "ns/op")
record("scalar", "string", (@b map(string, VALS) seconds=1), "ns/op")
record("scalar", "Float64 conversion", (@b map(Float64, VALS) seconds=1), "ns/op")
record("scalar", "round(digits=1)", (@b map(x -> round(x, digits=1), VALS) seconds=1), "ns/op")

# In 1.0 Base.parse delegates to Parsers.parse, so these rows duplicate the
# head-to-head parse rows above; they are kept so the two entry points can be
# checked against each other.
if NEW
    record("extra", "parse money (Parsers.parse)", (@b map(s -> Parsers.parse(T64, s), MONEY) seconds=1), "ns/op")
    record("extra", "parse 18-digit (Parsers.parse)", (@b map(s -> Parsers.parse(T18, s), D18) seconds=1), "ns/op")
    record("extra", "parse 38-digit (Parsers.parse)", (@b map(s -> Parsers.parse(T38, s), D38) seconds=1), "ns/op")
end

println(stderr, "== bulk (1M elements) ==")
const BIGSTRS = repeat(MONEY, 1000)
# parsed rather than `repeat`ed: under 0.5.1 `repeat` would share 1000 boxed
# values across all 1M slots and make the memory figure meaningless
const BIGV = map(pmoney, BIGSTRS)
# explicit `evals=1 samples=3`: under 0.5.1 a single bulk sample runs for tens of
# seconds, and Chairmarks' time budget would otherwise take exactly one sample —
# these are GC-dominated and need a minimum over repeats to be stable
record("bulk", "sum 1M", (@b sum(BIGV) evals=1 samples=5 seconds=Inf), "ms/1M"; per=1)
record("bulk", "sort 1M", (@b copy(BIGV) sort! evals=1 samples=3 seconds=Inf), "ms/1M"; per=1)
record("bulk", "parse 1M", (@b map(pmoney, BIGSTRS) evals=1 samples=3 seconds=Inf), "ms/1M"; per=1)
record("bulk", "maximum 1M", (@b maximum(BIGV) evals=1 samples=5 seconds=Inf), "ms/1M"; per=1)

println(stderr, "== memory ==")
const ELT = eltype(VALS)
push!(results, (LABEL, "memory", "sizeof(element)", Float64(sizeof(ELT)), "bytes", 0.0))
push!(results, (LABEL, "memory", "summarysize/element (1M vector)",
                Base.summarysize(BIGV) / 1_000_000, "bytes", 0.0))
push!(results, (LABEL, "memory", "isbits", Float64(isbitstype(ELT)), "bool", 0.0))
@printf(stderr, "  sizeof %d   summarysize/elem %.2f   isbits %s   eltype %s\n",
        sizeof(ELT), Base.summarysize(BIGV) / 1_000_000, isbitstype(ELT), ELT)

println("# impl=$LABEL decimals=$(pkgversion(Decimals)) julia=$(VERSION) cpu=$(strip(read(`sysctl -n machdep.cpu.brand_string`, String))) eltype=$ELT")
println("impl\tgroup\top\tvalue\tunit\tbytes_per_op")
for (impl, group, op, v, unit, bytes) in results
    @printf("%s\t%s\t%s\t%.6g\t%s\t%.6g\n", impl, group, op, v, unit, bytes)
end
