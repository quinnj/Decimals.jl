# Benchmark results (historical, 2026-08-31)

Superseded by [PERF.md](PERF.md).

This file recorded an interim comparison against DecFP, FixedPointDecimals,
rust_decimal, Python `decimal`, polars and duckdb, taken on an Apple M2 Max
before several later optimization rounds. Its figures no longer match the
current implementation and it is kept only as a pointer.

[PERF.md](PERF.md) carries the current methodology, machine and library
versions, tables, charts, caveats, and reproduction instructions; every number
in it is generated from the TSVs in `results/` by `regen_tables.py` and
`charts/gen_charts.py`.
