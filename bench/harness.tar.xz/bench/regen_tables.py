#!/usr/bin/env python3
"""Sync the Decimals 1.0 / 0.5.1 numeric cells of bench/PERF.md from bench/results/*.tsv.

Prose, other-library columns, and caveats are hand-written; run after `bench/run.sh new`.
"""
import os
import re
import statistics
import subprocess

B = os.path.dirname(os.path.abspath(__file__))


def tsv(name):
    """Rows of a results TSV, skipping comments, headers, and non-numeric rows."""
    rows = []
    with open(os.path.join(B, "results", name)) as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.rstrip('\n').split('\t')
            try:
                float(parts[3])
            except (ValueError, IndexError):
                continue
            rows.append(parts)
    return rows


def numcol(r, i):
    try:
        return float(r[i])
    except (ValueError, IndexError):
        return None


def fmt(x):
    return f"{x:.3f}" if x < 1 else (f"{x:.2f}" if x < 1000 else f"{x:,.2f}")


def fb(x):
    return "0" if x == 0 else (f"{x:.1f}" if x >= 100 else f"{x:.2f}")


new = {(r[1], r[2]): (float(r[3]), numcol(r, 5)) for r in tsv('oldvsnew-new.tsv')}
old = {(r[1], r[2]): (float(r[3]), numcol(r, 5)) for r in tsv('oldvsnew-old.tsv')}
cross = {(r[0], r[1], r[2]): float(r[3]) for r in tsv('crosslib.tsv')}
with open(os.path.join(B, 'results', 'bulkparse.tsv')) as f:
    bulk = [l.rstrip('\n').split('\t') for l in f
            if not l.startswith('#') and not l.startswith('impl')]

p = os.path.join(B, 'PERF.md')
with open(p) as f:
    s = f.read()

# section 1: scalar operations, old vs new
scalar_rows = [
    ('parse `"123456.78"`', 'parse money'), ('parse 18-digit', 'parse 18-digit'),
    ('parse 38-digit', 'parse 38-digit'), ('construct from Float64', 'from Float64'),
    ('construct from Int', 'from Int'), ('add', 'add'), ('subtract', 'subtract'),
    ('multiply', 'multiply'), ('divide', 'divide'), ('compare `a < b`', 'less-than'),
    ('compare `a < 1.5` (mixed)', 'compare to Float64'), ('equality `a == b`', 'equality'),
    ('hash', 'hash'), ('`string(x)`', 'string'),
    ('convert to Float64', 'Float64 conversion'), ('`round(x, digits=1)`', 'round(digits=1)'),
]
for label, op in scalar_rows:
    o, n = old[('scalar', op)], new[('scalar', op)]
    pat = re.compile(r'^\| ' + re.escape(label) + r' \| [\d.,]+ \| [\d.]+ \| .*$', re.M)
    assert pat.search(s), label
    s = pat.sub(f"| {label} | {o[0]:.2f} | {fmt(n[0])} | {o[0]/n[0]:.0f}× | {o[1]:.1f} | {fb(n[1])} |", s, count=1)

# section 2: bulk operations, old vs new
for label, op in [('sum 1M values', 'sum 1M'), ('`sort!` 1M values', 'sort 1M'),
                  ('`maximum` of 1M', 'maximum 1M')]:
    o, n = old[('bulk', op)][0], new[('bulk', op)][0]
    pat = re.compile(r'^\| ' + re.escape(label) + r' \| .*$', re.M)
    assert pat.search(s), label
    s = pat.sub(f"| {label} | {o:,.2f} ms | {n:.3f} ms | {o/n:.0f}× |", s, count=1)

# bulk parse comes from the per-process runs (bulkparse.tsv), favourable to 0.5.1
bo = statistics.median(float(r[2]) for r in bulk if r[0] == 'old')
bn = statistics.median(float(r[2]) for r in bulk if r[0] == 'new')
pat = re.compile(r'^\| parse 1M strings \| .*$', re.M)
assert pat.search(s)
s = pat.sub(f"| parse 1M strings | {bo:,.0f} ms | {bn:.2f} ms | {bo/bn:.0f}× |", s, count=1)

# section 4: the Decimals column of the cross-library table
for label, op in [('parse', 'parse'), ('format to String', 'format to String'), ('add', 'add'),
                  ('multiply', 'multiply'), ('divide', 'divide'), ('hash', 'hash'),
                  ('convert to Float64', 'Float64 conversion')]:
    v = cross[('scalar', 'Decimals 1.0', op)]
    pat = re.compile(r'^(\| ' + re.escape(label) + r' \| )(\*\*)?[\d.]+(\*\*)?( \| [\d.]+ \| (\*\*)?[\d.]+(\*\*)?( \|.*)?)$', re.M)
    m = pat.search(s)
    assert m, label
    bold = m.group(2) == '**'
    s = pat.sub(lambda mm: mm.group(1) + (f"**{v:.2f}**" if bold else f"{v:.3f}") + mm.group(4), s, count=1)

# section 6: parse-by-digit-width bands
for band, key, bold in (('1–4 digits', '1-4 digits', True), ('5–9 digits', '5-9 digits', True),
                        ('10–18 digits', '10-18 digits', False), ('19–38 digits', '19-38 digits', True),
                        ('39–76 digits', '39-76 digits', True)):
    v = cross[('bands', 'Decimals 1.0', key)]
    pat = re.compile(r'^(\| ' + re.escape(band) + r' \| )(\*\*)?[\d.]+(\*\*)?( \|.*)$', re.M)
    assert pat.search(s), band
    s = pat.sub(lambda mm: mm.group(1) + (f"**{v:.2f}**" if bold else f"{v:.2f}") + mm.group(4), s, count=1)

# section 4: every library column, winner in bold
fpd = {(r[0], r[1], r[2]): float(r[3]) for r in tsv('fpd.tsv')}
rust = {(r[0], r[1], r[2]): float(r[3]) for r in tsv('rust.tsv')}
pyd = {(r[0], r[1], r[2]): float(r[3]) for r in tsv('py-default.tsv')}


def cell(v):
    if v is None:
        return "—"
    return f"{v:.3f}" if v < 1 else f"{v:.2f}"


def row(label, values, suffix=None):
    """One table row; the smallest numeric cell is bold."""
    nums = [v for v in values if v is not None]
    best = min(nums) if len(nums) > 1 else None
    cells = []
    for i, v in enumerate(values):
        text = cell(v) + (suffix[i] if suffix and suffix[i] else "")
        cells.append(f"**{text}**" if v is not None and v == best else text)
    return f"| {label} | " + " | ".join(cells) + " |"


def replace_row(s, label, new_line, ncols):
    """Replace the row starting with `label` in the table with `ncols` value columns."""
    pat = re.compile(r'^\| ' + re.escape(label) + r' \|' + r'[^|\n]*\|' * ncols + r'$', re.M)
    m = pat.search(s)
    assert m, (label, ncols)
    return s[:m.start()] + new_line + s[m.end():]


i4 = s.index('## 4. Scalar operations vs other libraries')
i5 = s.index('## 5.', i4)
s4 = s[i4:i5]

for label, op in [('parse', 'parse'), ('format to String', 'format to String'), ('add', 'add'),
                  ('multiply', 'multiply'), ('divide', 'divide'), ('hash', 'hash'),
                  ('convert to Float64', 'Float64 conversion')]:
    values = [cross.get(('scalar', 'Decimals 1.0', op)), cross.get(('scalar', 'DecFP Dec64', op)),
              fpd.get(('scalar', 'FixedPointDecimals', op)), rust.get(('scalar', 'rust_decimal', op)),
              pyd.get(('scalar', 'Python decimal', op))]
    s4 = replace_row(s4, label, row(label, values), 5)

# the single-call table (three value columns)
for label, op in [('add', 'add'), ('convert to Float64', 'Float64 conversion')]:
    values = [cross.get(('call', 'Decimals 1.0', op)), fpd.get(('call', 'FixedPointDecimals', op)),
              cross.get(('call', 'DecFP Dec64', op))]
    s4 = replace_row(s4, label, row(label, values), 3)

# the 128-bit tier table (corpus column, then three value columns)
for label, corpus, dop, cop, fop in [('parse', '38 digits', 'parse', 'parse', 'parse'),
                                     ('format to String', '38 digits', 'format to String', 'format to String', 'format to String'),
                                     ('add', '29 digits', 'add (29 digits)', 'add (29 digits)', None),
                                     ('multiply', '29 digits', 'multiply (29 digits)', 'multiply (29 digits)', None)]:
    values = [cross.get(('wide', 'Decimals 1.0', dop)), cross.get(('wide', 'DecFP Dec128', cop)),
              fpd.get(('wide', 'FixedPointDecimals', fop)) if fop else None]
    s4 = replace_row(s4, f"{label} | {corpus}", row(f"{label} | {corpus}", values), 3)
s4 = replace_row(s4, 'add | 38 digits',
                 f"| add | 38 digits | — | — | {cell(fpd.get(('wide', 'FixedPointDecimals', 'add')))}¹ |", 3)
s = s[:i4] + s4 + s[i5:]

# the measured revision in the machine table
head = subprocess.run(['git', 'rev-parse', '--short', 'HEAD'], cwd=B, capture_output=True, text=True).stdout.strip()
s = re.sub(r'this branch at `[0-9a-f]+`', f'this branch at `{head}`', s)

with open(p, 'w') as f:
    f.write(s)
print("PERF.md numeric cells synced")
