# Decimals 1.0 vs DecFP (Intel decNumber via BID) on identical corpora, plus the
# parse-latency-by-digit-width sweep and the 1M columnar flows.
#
#   julia --startup-file=no --project=<new-env> bench/crosslib.jl > results/crosslib.tsv
#
# FixedPointDecimals is measured by bench/fpdbench.jl in a separate environment:
# its latest release pins Parsers 2.x, which would silently downgrade the Parsers
# version Decimals' own parse extension is measured against.
using Chairmarks, Printf, Decimals, Parsers
using Decimals: Int256, UInt256
import DecFP

const CORPORA = joinpath(@__DIR__, "corpora")
readcorpus(name) = readlines(joinpath(CORPORA, name))

const MONEY = readcorpus("money.txt")
const D38 = readcorpus("d38.txt")
# 29 significant digits: the 128-bit tier with enough headroom that a checked
# 1000-element fold cannot overflow. Decimals' `+` is checked and throws on
# overflow; DecFP's is floating and would silently round, so the operands have to
# stay inside both libraries' exact range for the comparison to mean anything.
const WIDE = readcorpus("wide29.txt")
const N = length(MONEY)

const T64 = Decimal64{2}
const T38 = Decimal{38,4,Int128}
const TW = Decimal{38,6,Int128}

results = Tuple{String,String,String,Float64,String}[]

function record(group, lib, op, b, unit; per=N)
    v = unit == "ns/op" ? 1e9 * b.time / per : 1e3 * b.time
    push!(results, (group, lib, op, v, unit))
    @printf(stderr, "  %-14s %-26s %12.3f %s\n", lib, op, v, unit)
    return nothing
end

addfold(v) = (s = v[1]; @inbounds for i in 2:length(v); s += v[i]; end; s)
mulfold(v) = (s = v[1] * v[2]; @inbounds for i in 2:length(v)-1; s += v[i] * v[i+1]; end; s)
divfold(v) = (s = v[1] / v[2]; @inbounds for i in 2:length(v)-1; s += v[i] / v[i+1]; end; s)
hashfold(v) = (h = UInt(0); @inbounds for x in v; h ⊻= hash(x); end; h)
nonzero(v) = map(x -> iszero(x) ? oneunit(x) : x, v)

const dv = map(s -> Parsers.parse(T64, s), MONEY)
const fv = map(s -> Base.parse(DecFP.Dec64, s), MONEY)
const dv128 = map(s -> Parsers.parse(T38, s), D38)
const fv128 = map(s -> Base.parse(DecFP.Dec128, s), D38)
const dvw = map(s -> Parsers.parse(TW, s), WIDE)
const fvw = map(s -> Base.parse(DecFP.Dec128, s), WIDE)
const dvnz, fvnz = nonzero(dv), nonzero(fv)

@info "Decimals v$(pkgversion(Decimals)) DecFP v$(pkgversion(DecFP)) Parsers v$(pkgversion(Parsers)) julia $(VERSION)"

println(stderr, "== scalar, money-shaped (Decimal64{2} / Dec64) ==")
record("scalar", "Decimals 1.0", "parse", (@b map(s -> Parsers.parse(T64, s), MONEY) seconds=1), "ns/op")
record("scalar", "DecFP Dec64", "parse", (@b map(s -> Base.parse(DecFP.Dec64, s), MONEY) seconds=1), "ns/op")
record("scalar", "Decimals 1.0", "format to String", (@b map(string, dv) seconds=1), "ns/op")
record("scalar", "DecFP Dec64", "format to String", (@b map(string, fv) seconds=1), "ns/op")
record("scalar", "Decimals 1.0", "add", (@b addfold(dv) seconds=1), "ns/op"; per=N - 1)
record("scalar", "DecFP Dec64", "add", (@b addfold(fv) seconds=1), "ns/op"; per=N - 1)
record("scalar", "Decimals 1.0", "multiply", (@b mulfold(dv) seconds=1), "ns/op"; per=N - 2)
record("scalar", "DecFP Dec64", "multiply", (@b mulfold(fv) seconds=1), "ns/op"; per=N - 2)
record("scalar", "Decimals 1.0", "divide", (@b divfold(dvnz) seconds=2), "ns/op"; per=N - 2)
record("scalar", "DecFP Dec64", "divide", (@b divfold(fvnz) seconds=2), "ns/op"; per=N - 2)
record("scalar", "Decimals 1.0", "hash", (@b hashfold(dv) seconds=1), "ns/op")
record("scalar", "DecFP Dec64", "hash", (@b hashfold(fv) seconds=1), "ns/op")
record("scalar", "Decimals 1.0", "Float64 conversion", (@b map(Float64, dv) seconds=1), "ns/op")
record("scalar", "DecFP Dec64", "Float64 conversion", (@b map(Float64, fv) seconds=1), "ns/op")
# single scalar calls (no loop to vectorize): the shape a user sees in a REPL
# or a non-vectorized code path
println(stderr, "== scalar, single call ==")
record("call", "Decimals 1.0", "add", (@b $(dv[1]) + $(dv[2]) seconds=1), "ns/op"; per=1)
record("call", "DecFP Dec64", "add", (@b $(fv[1]) + $(fv[2]) seconds=1), "ns/op"; per=1)
record("call", "Decimals 1.0", "Float64 conversion", (@b Float64($(dv[3])) seconds=1), "ns/op"; per=1)
record("call", "DecFP Dec64", "Float64 conversion", (@b Float64($(fv[3])) seconds=1), "ns/op"; per=1)

println(stderr, "== 128-bit tier (38 significant digits) ==")
record("wide", "Decimals 1.0", "parse", (@b map(s -> Parsers.parse(T38, s), D38) seconds=1), "ns/op")
record("wide", "DecFP Dec128", "parse", (@b map(s -> Base.parse(DecFP.Dec128, s), D38) seconds=1), "ns/op")
record("wide", "Decimals 1.0", "format to String", (@b map(string, dv128) seconds=1), "ns/op")
record("wide", "DecFP Dec128", "format to String", (@b map(string, fv128) seconds=1), "ns/op")
record("wide", "Decimals 1.0", "add (29 digits)", (@b addfold(dvw) seconds=1), "ns/op"; per=N - 1)
record("wide", "DecFP Dec128", "add (29 digits)", (@b addfold(fvw) seconds=1), "ns/op"; per=N - 1)
record("wide", "Decimals 1.0", "multiply (29 digits)", (@b mulfold(dvw) seconds=1), "ns/op"; per=N - 2)
record("wide", "DecFP Dec128", "multiply (29 digits)", (@b mulfold(fvw) seconds=1), "ns/op"; per=N - 2)

# ---- parse latency by digit width ----
# Decimals picks the narrowest storage that holds the band; DecFP has only two
# widths, and Dec128 tops out at 34 significant digits, so the 39-76 band is
# rounded (inexact) on the DecFP side, as PERF.md records. The DecFP width is
# chosen by the band's widest input, not its first: Dec64 holds 16 significant
# digits, so anything above the 5-9 band must use Dec128 or DecFP would be
# rounding while Decimals stays exact.
const BANDS = [("1-4 digits", "band1_4.txt", Decimal{18,1,Int64}, DecFP.Dec64, "DecFP Dec64"),
               ("5-9 digits", "band5_9.txt", Decimal{18,2,Int64}, DecFP.Dec64, "DecFP Dec64"),
               ("10-18 digits", "band10_18.txt", Decimal{18,4,Int64}, DecFP.Dec128, "DecFP Dec128"),
               ("19-38 digits", "band19_38.txt", Decimal{38,6,Int128}, DecFP.Dec128, "DecFP Dec128"),
               ("39-76 digits", "band39_76.txt", Decimal{76,8,Int256}, DecFP.Dec128, "DecFP Dec128")]

println(stderr, "== parse by digit width ==")
for (label, file, T, DT, dlabel) in BANDS
    strs = readcorpus(file)
    record("bands", "Decimals 1.0", label, (@b map(s -> Parsers.parse(T, s), strs) seconds=1), "ns/op")
    record("bands", dlabel, label, (@b map(s -> Base.parse(DT, s), strs) seconds=1), "ns/op")
end

# ---- 1M columnar flows ----
println(stderr, "== columnar, 1M elements, single thread ==")
const BIGSTRS = repeat(MONEY, 1000)
const BIGD = repeat(dv, 1000)
const BIGF = repeat(fv, 1000)
parseall(::Type{T}, strs) where {T} = map(s -> Parsers.parse(T, s), strs)
parseallfp(::Type{T}, strs) where {T} = map(s -> Base.parse(T, s), strs)
record("bulk", "Decimals 1.0", "parse 1M", (@b parseall(T64, BIGSTRS) seconds=5), "ms/1M"; per=1)
record("bulk", "DecFP Dec64", "parse 1M", (@b parseallfp(DecFP.Dec64, BIGSTRS) seconds=5), "ms/1M"; per=1)
record("bulk", "Decimals 1.0", "sum 1M", (@b sum(BIGD) seconds=5), "ms/1M"; per=1)
record("bulk", "DecFP Dec64", "sum 1M", (@b sum(BIGF) seconds=5), "ms/1M"; per=1)
record("bulk", "Decimals 1.0", "multiply 1M", (@b BIGD .* BIGD seconds=5), "ms/1M"; per=1)
record("bulk", "DecFP Dec64", "multiply 1M", (@b BIGF .* BIGF seconds=5), "ms/1M"; per=1)

println("# decimals=$(pkgversion(Decimals)) decfp=$(pkgversion(DecFP)) parsers=$(pkgversion(Parsers)) julia=$(VERSION) cpu=$(strip(read(`sysctl -n machdep.cpu.brand_string`, String)))")
println("group\tlib\top\tvalue\tunit")
for (group, lib, op, v, unit) in results
    @printf("%s\t%s\t%s\t%.6g\t%s\n", group, lib, op, v, unit)
end
