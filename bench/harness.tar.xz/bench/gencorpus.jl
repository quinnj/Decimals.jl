# Generate the shared benchmark corpora once, as plain text files, so that every
# runner (Julia old/new envs, Rust, Python) parses byte-identical input.
#   julia --startup-file=no bench/gencorpus.jl
# Writes bench/corpora/*.txt (committed, so results are reproducible).
using Random

const OUT = joinpath(@__DIR__, "corpora")

# one seeded stream for the whole file: regenerating always yields the same corpora
const RNG = Xoshiro(20260902)

# a decimal string with `d` significant digits, `f` of them after the point
function digitstr(rng, d::Int, f::Int)
    digits = string(rand(rng, '1':'9')) * String(rand(rng, ['0':'9';], d - 1))
    s = rand(rng, Bool) ? "-" : ""
    f == 0 && return s * digits
    return s * digits[1:d-f] * "." * digits[d-f+1:end]
end

# a band corpus: each entry has a random digit count inside [lo, hi]
function band(rng, n, lo, hi, f)
    return [digitstr(rng, d, min(f, d - 1)) for d in rand(rng, lo:hi, n)]
end

write_corpus(name, lines) = (open(joinpath(OUT, name), "w") do io
    for l in lines
        println(io, l)
    end
end; println("wrote $name  ($(length(lines)) lines)"))

function main()
    mkpath(OUT)
    n = 1000
    # money-shaped: ddddddd.dd, the shape of a currency column
    money = [string(rand(RNG, -99999999:99999999) / 100) for _ in 1:n]
    # string(x/100) can drop a trailing zero ("1234.5"); pad so every entry is scale-2
    money = map(s -> occursin('.', s) ? rpad(s, length(split(s, '.')[1]) + 3, '0') : s * ".00", money)
    write_corpus("money.txt", money)
    # 18 significant digits (15 integer + 3 fraction): the widest Int64-backed shape
    write_corpus("d18.txt", [digitstr(RNG, 18, 3) for _ in 1:n])
    # 38 significant digits (34 integer + 4 fraction): the Int128 tier
    write_corpus("d38.txt", [digitstr(RNG, 38, 4) for _ in 1:n])
    # digit-count bands for the parse-latency-by-width chart
    write_corpus("band1_4.txt", band(RNG, n, 1, 4, 1))
    write_corpus("band5_9.txt", band(RNG, n, 5, 9, 2))
    write_corpus("band10_18.txt", band(RNG, n, 10, 18, 4))
    write_corpus("band19_38.txt", band(RNG, n, 19, 38, 6))
    write_corpus("band39_76.txt", band(RNG, n, 39, 76, 8))
    # 29 significant digits (23 integer + 6 fraction) for the 128-bit tier's
    # arithmetic comparison: wide enough to need Int128, with enough headroom that
    # a checked 1000-element fold cannot overflow Decimal{38,6,Int128}
    write_corpus("wide29.txt", [digitstr(RNG, 29, 6) for _ in 1:n])
    return nothing
end

main()
