#!/usr/bin/env python3
"""Python stdlib `decimal` (libmpdec), polars and duckdb on the same corpora.

    python3 bench/pybench.py <bench-dir> [1t]

`1t` pins polars and duckdb to a single thread; without it both use their
default thread pool. Emits the same TSV shape as the Julia/Rust harnesses.
"""
import os
import sys
import time

BENCH = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
ONE_THREAD = len(sys.argv) > 2 and sys.argv[2] == "1t"
SUFFIX = " 1T" if ONE_THREAD else ""
if ONE_THREAD:
    os.environ["POLARS_MAX_THREADS"] = "1"


def load(name):
    with open(os.path.join(BENCH, "corpora", name)) as f:
        return [l.strip() for l in f if l.strip()]


MONEY = load("money.txt")
N = len(MONEY)
BIG = MONEY * 1000  # 1M


def best(f, reps=7):
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter_ns()
        f()
        ts.append(time.perf_counter_ns() - t0)
    return min(ts)


def row(group, lib, op, v, unit):
    print(f"{group}\t{lib}\t{op}\t{v:.6f}\t{unit}", flush=True)


# ---------------- python stdlib decimal ----------------
if not ONE_THREAD:
    from decimal import Decimal as PyDec

    vals = [PyDec(s) for s in MONEY]
    nz = [v if v != 0 else PyDec(1) for v in vals]
    row("scalar", "Python decimal", "parse", best(lambda: [PyDec(s) for s in MONEY]) / N, "ns/op")
    row("scalar", "Python decimal", "format to String", best(lambda: [str(v) for v in vals]) / N, "ns/op")
    row("scalar", "Python decimal", "add", best(lambda: sum(vals)) / (N - 1), "ns/op")

    def mulfold():
        s = vals[0] * vals[1]
        for i in range(1, len(vals) - 1):
            s += vals[i] * vals[i + 1]
        return s

    def divfold():
        s = nz[0] / nz[1]
        for i in range(1, len(nz) - 1):
            s += nz[i] / nz[i + 1]
        return s

    row("scalar", "Python decimal", "multiply", best(mulfold) / (N - 2), "ns/op")
    row("scalar", "Python decimal", "divide", best(divfold, 5) / (N - 2), "ns/op")
    row("scalar", "Python decimal", "Float64 conversion", best(lambda: [float(v) for v in vals]) / N, "ns/op")

    bigvals = vals * 1000
    row("bulk", "Python decimal", "parse 1M", best(lambda: [PyDec(s) for s in BIG], 3) / 1e6, "ms/1M")
    row("bulk", "Python decimal", "sum 1M", best(lambda: sum(bigvals), 3) / 1e6, "ms/1M")

# ---------------- polars ----------------
import polars as pl  # noqa: E402

DEC = pl.Decimal(precision=18, scale=2)
df = pl.DataFrame({"s": BIG})
row("bulk", f"polars{SUFFIX}", "parse 1M", best(lambda: df.select(pl.col("s").cast(DEC)), 5) / 1e6, "ms/1M")
dec = df.select(pl.col("s").cast(DEC).alias("d"))
row("bulk", f"polars{SUFFIX}", "sum 1M", best(lambda: dec.select(pl.col("d").sum()), 7) / 1e6, "ms/1M")
row("bulk", f"polars{SUFFIX}", "multiply 1M", best(lambda: dec.select(pl.col("d") * pl.col("d")), 5) / 1e6, "ms/1M")
row("bulk", f"polars{SUFFIX}", "format 1M", best(lambda: dec.select(pl.col("d").cast(pl.Utf8)), 5) / 1e6, "ms/1M")

# ---------------- duckdb ----------------
import duckdb  # noqa: E402

con = duckdb.connect(config={"threads": 1}) if ONE_THREAD else duckdb.connect()
con.execute("create table t as select s from (select unnest(?::varchar[]) s)", [BIG])
row("bulk", f"duckdb{SUFFIX}", "parse 1M",
    best(lambda: con.execute("create or replace table d as select cast(s as decimal(18,2)) v from t"), 5) / 1e6, "ms/1M")
row("bulk", f"duckdb{SUFFIX}", "sum 1M",
    best(lambda: con.execute("select sum(v) from d").fetchall(), 7) / 1e6, "ms/1M")
row("bulk", f"duckdb{SUFFIX}", "multiply 1M",
    best(lambda: con.execute("create or replace table m as select v*v p from d"), 5) / 1e6, "ms/1M")
row("bulk", f"duckdb{SUFFIX}", "format 1M",
    best(lambda: con.execute("create or replace table f as select cast(v as varchar) s2 from d"), 5) / 1e6, "ms/1M")

print(f"# python={sys.version.split()[0]} polars={pl.__version__} duckdb={duckdb.__version__} "
      f"polars_threads={pl.thread_pool_size()} onethread={ONE_THREAD}", file=sys.stderr)
