# Decimals 1.0 columnar flows at 1 thread and at all threads, on the shared
# corpus, so the comparison against polars/duckdb default parallelism is
# apples-to-apples.
#
#   julia --startup-file=no -t auto --project=<new-env> bench/mtbulk.jl > results/mtbulk.tsv
using Chairmarks, Printf, Decimals, Parsers
using Decimals: Int256, UInt256

const CORPORA = joinpath(@__DIR__, "corpora")
const MONEY = readlines(joinpath(CORPORA, "money.txt"))
const BIGSTRS = repeat(MONEY, 1000)
const T = Decimal64{2}
const VALS = map(s -> Parsers.parse(T, s), BIGSTRS)
const NT = Threads.nthreads()
const ACC = Decimal{38,2,Int128}

function mtsum(v, nch)
    n = length(v)
    chunk = cld(n, nch)
    parts = Vector{ACC}(undef, nch)
    Threads.@threads for c in 1:nch
        lo, hi = (c - 1) * chunk + 1, min(c * chunk, n)
        parts[c] = lo <= hi ? sum(view(v, lo:hi)) : zero(ACC)
    end
    return sum(parts)
end

function mtparse(strs, nch)
    n = length(strs)
    chunk = cld(n, nch)
    out = Vector{T}(undef, n)
    Threads.@threads for c in 1:nch
        lo, hi = (c - 1) * chunk + 1, min(c * chunk, n)
        for i in lo:hi
            @inbounds out[i] = Parsers.parse(T, strs[i])
        end
    end
    return out
end

@assert mtsum(VALS, NT) == sum(VALS)
@assert mtparse(BIGSTRS, NT) == VALS

results = Tuple{String,String,String,Float64,String}[]
function record(lib, op, b)
    v = 1e3 * b.time
    push!(results, ("bulk", lib, op, v, "ms/1M"))
    @printf(stderr, "  %-22s %-14s %9.3f ms\n", lib, op, v)
    return nothing
end

@info "Decimals v$(pkgversion(Decimals)) julia $(VERSION) threads=$NT"
record("Decimals 1.0 1T", "parse 1M", @b mtparse(BIGSTRS, 1) seconds=5)
record("Decimals 1.0 $(NT)T", "parse 1M", @b mtparse(BIGSTRS, NT) seconds=5)
record("Decimals 1.0 1T", "sum 1M", @b sum(VALS) seconds=5)
record("Decimals 1.0 $(NT)T", "sum 1M", @b mtsum(VALS, NT) seconds=5)

println("# decimals=$(pkgversion(Decimals)) julia=$(VERSION) threads=$NT cpu=$(strip(read(`sysctl -n machdep.cpu.brand_string`, String)))")
println("group\tlib\top\tvalue\tunit")
for (group, lib, op, v, unit) in results
    @printf("%s\t%s\t%s\t%.6g\t%s\n", group, lib, op, v, unit)
end
