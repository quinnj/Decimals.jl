# One timed 1M-element `Base.parse` into a fresh process, for both releases.
#
#   julia --startup-file=no --project=<env> bench/bulkparse.jl <old|new>   # repeat, take the min
#
# Why its own process: under 0.5.1 the parsed column is 1M boxed values, so the
# cost of this loop depends on what else is already live on the heap. Measured
# inside bench/oldvsnew.jl, where a 1M-element column is already retained, the
# same loop costs several times more, because every GC must trace millions of
# BigInts. A pristine heap is the measurement most favourable to 0.5.1, so that
# is the one reported.
using Decimals
try; @eval using Parsers; catch; end  # 1.0: parse/tryparse come from the Parsers extension

const NEW = isdefined(Decimals, :Decimal64)
const MONEY = readlines(joinpath(@__DIR__, "corpora", "money.txt"))
const BIGSTRS = repeat(MONEY, 1000)

if NEW
    const T = Decimal64{2}
    p(s) = Base.parse(T, s)
else
    p(s) = Base.parse(Decimal, s)
end

map(p, MONEY)  # warm up / compile
GC.gc(true)
t = @elapsed v = map(p, BIGSTRS)
@assert length(v) == 1_000_000
println(round(1e3 * t, digits=2), " ms")
