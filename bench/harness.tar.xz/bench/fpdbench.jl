# FixedPointDecimals on the same corpora, in its own environment.
# FixedPointDecimals 0.6 pins Parsers to 2.x; running it alongside Decimals would
# downgrade the Parsers release that Decimals' parse extension is measured against,
# so it gets a dedicated env. Nothing here depends on Parsers.
#
#   julia --startup-file=no --project=<fpd-env> bench/fpdbench.jl > results/fpd.tsv
using Chairmarks, Printf, FixedPointDecimals

const FD = FixedPointDecimals.FixedDecimal
const CORPORA = joinpath(@__DIR__, "corpora")
readcorpus(name) = readlines(joinpath(CORPORA, name))

const MONEY = readcorpus("money.txt")
const D38 = readcorpus("d38.txt")
const N = length(MONEY)
const T = FD{Int64,2}
const T128 = FD{Int128,4}

addfold(v) = (s = v[1]; @inbounds for i in 2:length(v); s += v[i]; end; s)
mulfold(v) = (s = v[1] * v[2]; @inbounds for i in 2:length(v)-1; s += v[i] * v[i+1]; end; s)
divfold(v) = (s = v[1] / v[2]; @inbounds for i in 2:length(v)-1; s += v[i] / v[i+1]; end; s)
hashfold(v) = (h = UInt(0); @inbounds for x in v; h ⊻= hash(x); end; h)
nonzero(v) = map(x -> iszero(x) ? oneunit(x) : x, v)

const vals = map(s -> Base.parse(T, s), MONEY)
const nz = nonzero(vals)
const vals128 = map(s -> Base.parse(T128, s), D38)

results = Tuple{String,String,String,Float64,String}[]
function record(group, op, b, unit; per=N)
    v = unit == "ns/op" ? 1e9 * b.time / per : 1e3 * b.time
    push!(results, (group, "FixedPointDecimals", op, v, unit))
    @printf(stderr, "  %-26s %12.3f %s\n", op, v, unit)
    return nothing
end

@info "FixedPointDecimals v$(pkgversion(FixedPointDecimals)) julia $(VERSION)"
record("scalar", "parse", (@b map(s -> Base.parse(T, s), MONEY) seconds=1), "ns/op")
record("scalar", "format to String", (@b map(string, vals) seconds=1), "ns/op")
record("scalar", "add", (@b addfold(vals) seconds=1), "ns/op"; per=N - 1)
record("scalar", "multiply", (@b mulfold(vals) seconds=1), "ns/op"; per=N - 2)
record("scalar", "divide", (@b divfold(nz) seconds=2), "ns/op"; per=N - 2)
record("scalar", "hash", (@b hashfold(vals) seconds=1), "ns/op")
record("scalar", "Float64 conversion", (@b map(Float64, vals) seconds=1), "ns/op")
record("call", "add", (@b $(vals[1]) + $(vals[2]) seconds=1), "ns/op"; per=1)
record("call", "Float64 conversion", (@b Float64($(vals[3])) seconds=1), "ns/op"; per=1)
record("wide", "parse", (@b map(s -> Base.parse(T128, s), D38) seconds=1), "ns/op")
record("wide", "format to String", (@b map(string, vals128) seconds=1), "ns/op")
record("wide", "add", (@b addfold(vals128) seconds=1), "ns/op"; per=N - 1)

const BIGSTRS = repeat(MONEY, 1000)
const BIGV = repeat(vals, 1000)
record("bulk", "parse 1M", (@b map(s -> Base.parse(T, s), BIGSTRS) seconds=5), "ms/1M"; per=1)
record("bulk", "sum 1M", (@b sum(BIGV) seconds=5), "ms/1M"; per=1)
record("bulk", "multiply 1M", (@b BIGV .* BIGV seconds=5), "ms/1M"; per=1)

println("# fixedpointdecimals=$(pkgversion(FixedPointDecimals)) julia=$(VERSION) cpu=$(strip(read(`sysctl -n machdep.cpu.brand_string`, String)))")
println("group\tlib\top\tvalue\tunit")
for (group, lib, op, v, unit) in results
    @printf("%s\t%s\t%s\t%.6g\t%s\n", group, lib, op, v, unit)
end
