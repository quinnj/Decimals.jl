#!/bin/bash
# Re-runnable driver for the Decimals 1.0 performance evidence.
#
#   bench/run.sh envs      build the three pinned Julia environments (once)
#   bench/run.sh new       measure Decimals 1.0 (the dev checkout)      -> results/oldvsnew-new.tsv, crosslib.tsv, mtbulk.tsv, memory-new.tsv, bulkparse (new)
#   bench/run.sh old       measure registered Decimals 0.5.1            -> results/oldvsnew-old.tsv, memory-old.tsv, bulkparse (old)
#   bench/run.sh others    measure FixedPointDecimals, rust, python     -> results/fpd.tsv, rust.tsv, py-default.tsv, py-1t.tsv
#   bench/run.sh charts    regenerate SVG + PNG from whatever is in results/
#   bench/run.sh all       envs, old, others, new, charts
#
# "new" is the only side that changes when the package changes; re-running it is
# enough to refresh every Decimals 1.0 number in PERF.md.
#
# Quiet-machine protocol: this script refuses to measure while another process is
# burning CPU. Set FORCE=1 to measure anyway, at the cost of noisier figures.
set -euo pipefail
BENCH=$(cd "$(dirname "$0")" && pwd)
REPO=$(cd "$BENCH/.." && pwd)
ENVS=${DECIMALS_BENCH_ENVS:-$BENCH/.envs}
RES=$BENCH/results
JULIA=${JULIA:-julia}
mkdir -p "$RES"

# Instantaneous idle from `top`, not the load average and not ps's lifetime-average
# %CPU (both mislead badly on macOS). The benchmarks are single-threaded, so what
# matters is that a core is actually free.
quiet_check() {
  [ "${FORCE:-0}" = "1" ] && return 0
  local idle other
  idle=$(top -l 2 -n 0 2>/dev/null | grep '^CPU usage' | tail -1 | sed -E 's/.*[, ]([0-9.]+)% idle.*/\1/' | cut -d. -f1)
  other=$(pgrep -f "bin/julia" | wc -l | tr -d ' ')
  echo "quiet check: ${idle}% idle, $other julia process(es) alive"
  if [ "${idle:-0}" -lt 50 ]; then
    echo "WARNING: only ${idle}% CPU idle — measurements will drift." >&2
    echo "         wait for the machine to settle, or set FORCE=1 to measure anyway." >&2
    return 1
  fi
  return 0
}

banner() { echo; echo "=== $* ==="; uptime; }

cmd_envs() {
  banner "building environments in $ENVS"
  rm -rf "$ENVS"
  BENCH_ENVS="$ENVS" BENCH_REPO="$REPO" "$JULIA" --startup-file=no -e "
    using Pkg
    envs = ENV[\"BENCH_ENVS\"]
    Pkg.activate(joinpath(envs, \"old\"));  Pkg.add(name=\"Decimals\", version=\"0.5.1\"); Pkg.add(\"Chairmarks\")
    Pkg.activate(joinpath(envs, \"new\"));  Pkg.develop(path=ENV[\"BENCH_REPO\"]); Pkg.add([\"Chairmarks\", \"Parsers\", \"DecFP\"])
    # FixedPointDecimals 0.6 pins Parsers 2.x; it gets its own env so it cannot
    # downgrade the Parsers release Decimals' parse extension is measured against
    Pkg.activate(joinpath(envs, \"fpd\"));  Pkg.add([\"Chairmarks\", \"FixedPointDecimals\"])
  "
}

cmd_new() {
  quiet_check || exit 1
  banner "Decimals 1.0 (dev checkout at $REPO)"
  cd "$REPO"
  "$JULIA" --startup-file=no --project="$ENVS/new" bench/oldvsnew.jl new > "$RES/oldvsnew-new.tsv"
  "$JULIA" --startup-file=no --project="$ENVS/new" bench/crosslib.jl  > "$RES/crosslib.tsv"
  "$JULIA" --startup-file=no -t auto --project="$ENVS/new" bench/mtbulk.jl > "$RES/mtbulk.tsv"
  "$JULIA" --startup-file=no --project="$ENVS/new" bench/memory.jl new > "$RES/memory-new.tsv"
  bulkparse new "$ENVS/new"
}

cmd_old() {
  quiet_check || exit 1
  banner "registered Decimals 0.5.1"
  cd "$REPO"
  "$JULIA" --startup-file=no --project="$ENVS/old" bench/oldvsnew.jl old > "$RES/oldvsnew-old.tsv"
  "$JULIA" --startup-file=no --project="$ENVS/old" bench/memory.jl old > "$RES/memory-old.tsv"
  bulkparse old "$ENVS/old"
}

# 1M parse, one fresh process per repeat (see bench/bulkparse.jl for why)
bulkparse() {
  local side=$1 env=$2 i out v
  out=$RES/bulkparse-$side.tsv
  { echo "# bench/bulkparse.jl, one timed 1M-element Base.parse per process."
    printf 'impl\tsample\tvalue\tunit\n'; } > "$out"
  for i in 1 2 3; do
    v=$("$JULIA" --startup-file=no --project="$env" "$BENCH/bulkparse.jl" "$side" | awk '{print $1}')
    printf '%s\t%d\t%s\tms/1M\n' "$side" "$i" "$v" >> "$out"
  done
  cat "$RES"/bulkparse-*.tsv | awk 'BEGIN{print "impl\tsample\tvalue\tunit"} !/^#/ && !/^impl/' > "$RES/bulkparse.tsv"
  echo "wrote $out"
}

cmd_others() {
  quiet_check || exit 1
  banner "FixedPointDecimals / rust_decimal / Python+polars+duckdb"
  cd "$REPO"
  "$JULIA" --startup-file=no --project="$ENVS/fpd" bench/fpdbench.jl > "$RES/fpd.tsv"
  (cd "$BENCH/rustbench" && cargo build --release -q)
  sleep 2   # let the compile settle before timing
  "$BENCH/rustbench/target/release/rustbench" "$BENCH" > "$RES/rust.tsv"
  python3 "$BENCH/pybench.py" "$BENCH"    > "$RES/py-default.tsv"
  python3 "$BENCH/pybench.py" "$BENCH" 1t > "$RES/py-1t.tsv"
}

cmd_charts() {
  banner "charts"
  python3 "$BENCH/charts/gen_charts.py"
  "$BENCH/charts/render_png.sh"
}

case "${1:-all}" in
  envs) cmd_envs ;;
  new) cmd_new ;;
  old) cmd_old ;;
  others) cmd_others ;;
  charts) cmd_charts ;;
  all) cmd_envs; cmd_old; cmd_others; cmd_new; cmd_charts ;;
  *) echo "usage: $0 {envs|old|new|others|charts|all}" >&2; exit 2 ;;
esac
