# Memory footprint of a 1M-element decimal column, in both releases.
#
#   julia --startup-file=no --project=<env> bench/memory.jl <old|new>
#
# Three figures, because no single one tells the whole story:
#   sizeof(eltype)        - the element as the type system sees it
#   summarysize/element   - Julia's object-graph walk (misses GMP limb buffers)
#   live-bytes/element    - GC live-heap delta across building the column, which
#                           does include GMP allocations (they go through Julia's
#                           counted allocator)
using Decimals
try; @eval using Parsers; catch; end  # 1.0: parse/tryparse come from the Parsers extension

const NEW = isdefined(Decimals, :Decimal64)
const LABEL = length(ARGS) >= 1 ? ARGS[1] : (NEW ? "new" : "old")
const MONEY = readlines(joinpath(@__DIR__, "corpora", "money.txt"))
const BIGSTRS = repeat(MONEY, 1000)

if NEW
    const T = Decimal64{2}
    p(s) = Base.parse(T, s)
else
    p(s) = Base.parse(Decimal, s)
end

map(p, MONEY)  # warm up / compile
GC.gc(true); GC.gc(true)
before = Base.gc_live_bytes()
v = map(p, BIGSTRS)
GC.gc(true); GC.gc(true)
after = Base.gc_live_bytes()
E = eltype(v)

println("impl\tmetric\tvalue\tunit")
println("$LABEL\tsizeof(element)\t$(sizeof(E))\tbytes")
println("$LABEL\tsummarysize/element\t$(Base.summarysize(v) / 1e6)\tbytes")
println("$LABEL\tlive-bytes/element\t$((after - before) / 1e6)\tbytes")
println("$LABEL\tisbits\t$(Int(isbitstype(E)))\tbool")
println("# eltype=$E decimals=$(pkgversion(Decimals)) julia=$(VERSION)")
