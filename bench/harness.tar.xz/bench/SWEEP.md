# Perf-cliff sweep findings (historical, 2026-08-31)

Superseded by [PERF.md](PERF.md).

This file recorded a one-off probe of tier boundaries, slow paths and semantic
edges, run with `bench/sweep.jl` on an Apple M2 Max before several later
optimization rounds. Its figures no longer match the current implementation and
it is kept only as a pointer.

`bench/sweep.jl` is still the way to re-run that probe against the current
checkout; [PERF.md](PERF.md) carries the current methodology, tables, charts,
caveats, and reproduction instructions.

Two measurement notes from the sweep are still worth keeping:

- Audit allocations through typed-argument functions. Closures over non-const
  globals box their captures and report allocations that the operation itself
  does not perform.
- Clamped byte-gathers and wide-register SWAR lose to plain per-byte loops on
  short varied tokens, and overlapping 8-byte loads are only safe inside larger
  buffers. Both constraints are encoded in the parser's structure and comments.
