# Cross-package benchmark: Decimals.jl vs DecFP.jl vs FixedPointDecimals.jl vs
# Float64 across parse/format/arithmetic/columnar flows.
# Run from an environment with all four packages plus Chairmarks and Parsers.
using Chairmarks, Printf, Random
using Decimals, Parsers
using Decimals: Int256, UInt256
using Decimals: writedecimal!
import DecFP
import FixedPointDecimals
const FD = FixedPointDecimals.FixedDecimal

const rng = Xoshiro(2026)

# money-shaped corpus: ddddddd.dd values, and a 37-digit corpus
const STRS = [string(rand(rng, -99999999:99999999) / 100) for _ in 1:1000]
# 26 integer digits + 6 fraction digits: exercises the 128-bit tier while
# leaving headroom so a checked 1000-element sum cannot overflow P=38
const WIDESTRS = [string(rand(rng, big(-10)^25:big(10)^25)) * "." *
                  lpad(rand(rng, 0:999999), 6, '0') for _ in 1:1000]

const D64 = Decimal64{2}
const D128 = Decimal128{6}

const vals_d64 = [Parsers.parse(D64, s) for s in STRS]
const vals_d128 = [Parsers.parse(D128, s) for s in WIDESTRS]
const vals_dec64 = [Base.parse(DecFP.Dec64, s) for s in STRS]
const vals_dec128 = [Base.parse(DecFP.Dec128, s) for s in WIDESTRS]
const vals_fd = [Base.parse(FD{Int64,2}, s) for s in STRS]
const vals_f64 = [Base.parse(Float64, s) for s in STRS]

nonzero(v) = map(x -> iszero(x) ? oneunit(x) : x, v)
const vals_d64nz = nonzero(vals_d64)
const vals_dec64nz = nonzero(vals_dec64)
const vals_fdnz = nonzero(vals_fd)
const vals_f64nz = nonzero(vals_f64)

# per-element time over the 1000-value corpus
perel(name, b) = @printf("  %-36s %9.2f ns/op\n", name, 1e9 * b.time / 1000)
total(name, b) = @printf("  %-36s %9.3f ms\n", name, 1e3 * b.time)

println("== parse (money-shaped \"1234567.89\") ==")
perel("Decimals Parsers.parse D64{2}", @b map(s -> Parsers.parse(D64, s), STRS) seconds=1)
perel("DecFP Base.parse Dec64", @b map(s -> Base.parse(DecFP.Dec64, s), STRS) seconds=1)
perel("FPD Base.parse FD{Int64,2}", @b map(s -> Base.parse(FD{Int64,2}, s), STRS) seconds=1)
perel("Base.parse Float64", @b map(s -> Base.parse(Float64, s), STRS) seconds=1)
perel("Parsers.parse Float64", @b map(s -> Parsers.parse(Float64, s), STRS) seconds=1)

println("\n== parse (37 digits, 128-bit tier) ==")
perel("Decimals Parsers.parse D128{6}", @b map(s -> Parsers.parse(D128, s), WIDESTRS) seconds=1)
perel("DecFP Base.parse Dec128", @b map(s -> Base.parse(DecFP.Dec128, s), WIDESTRS) seconds=1)

println("\n== format ==")
const OUTBUF = zeros(UInt8, 256)
perel("Decimals string(D64{2})", @b map(string, vals_d64) seconds=1)
perel("Decimals writedecimal! (no alloc)", @b foreach(x -> writedecimal!(OUTBUF, 1, x), vals_d64) seconds=1)
perel("DecFP string(Dec64)", @b map(string, vals_dec64) seconds=1)
perel("FPD string(FD{Int64,2})", @b map(string, vals_fd) seconds=1)
perel("Base string(Float64)", @b map(string, vals_f64) seconds=1)
perel("Decimals string(D128{6})", @b map(string, vals_d128) seconds=1)
perel("DecFP string(Dec128)", @b map(string, vals_dec128) seconds=1)

# folds keep data dependencies real; per-op figures divide by corpus size
function mulfold(v)
    s = zero(first(v) * first(v))
    @inbounds for i in 1:length(v)-1
        s += v[i] * v[i+1]
    end
    return s
end
function divfold(v)
    s = zero(first(v) / first(v))
    @inbounds for i in 1:length(v)-1
        s += v[i] / v[i+1]
    end
    return s
end

println("\n== add: sum over 1000 values ==")
perel("Decimals sum D64{2} (Int128 acc)", @b sum(vals_d64) seconds=1)
perel("DecFP sum Dec64", @b sum(vals_dec64) seconds=1)
perel("FPD sum FD{Int64,2} (wrapping)", @b sum(vals_fd) seconds=1)
perel("Float64 sum", @b sum(vals_f64) seconds=1)
perel("Decimals sum D128{6}", @b sum(vals_d128) seconds=1)
perel("DecFP sum Dec128", @b sum(vals_dec128) seconds=1)

println("\n== multiply (chained a[i]*a[i+1] + accumulate) ==")
perel("Decimals D64{2} mul", @b mulfold(vals_d64) seconds=1)
perel("DecFP Dec64 mul", @b mulfold(vals_dec64) seconds=1)
perel("FPD FD{Int64,2} mul (rounding)", @b mulfold(vals_fd) seconds=1)
perel("Float64 mul", @b mulfold(vals_f64) seconds=1)

println("\n== divide (chained) ==")
perel("Decimals D64{2} div", @b divfold(vals_d64nz) seconds=1)
perel("DecFP Dec64 div", @b divfold(vals_dec64nz) seconds=1)
perel("FPD FD{Int64,2} div", @b divfold(vals_fdnz) seconds=1)
perel("Float64 div", @b divfold(vals_f64nz) seconds=1)

println("\n== conversions / rescale / sort ==")
perel("Decimals Float64(D64{2})", @b map(Float64, vals_d64) seconds=1)
perel("DecFP Float64(Dec64)", @b map(Float64, vals_dec64) seconds=1)
perel("Decimals rescale D64{2}->D64{4}", @b map(x -> rescale(Decimal{18,4,Int64}, x), vals_d64) seconds=1)
perel("Decimals round digits=1", @b map(x -> round(x, digits=1), vals_d64) seconds=1)
total("Decimals sort! 1000", @b sort!(copy(vals_d64)) seconds=1)
total("DecFP sort! 1000", @b sort!(copy(vals_dec64)) seconds=1)
total("FPD sort! 1000", @b sort!(copy(vals_fd)) seconds=1)

println("\n== columnar: 1M-element sum ==")
const bigv_d = repeat(vals_d64, 1000)
const bigv_dec = repeat(vals_dec64, 1000)
const bigv_fd = repeat(vals_fd, 1000)
const bigv_f = repeat(vals_f64, 1000)
total("Decimals sum 1M D64{2}", @b sum(bigv_d) seconds=2)
total("DecFP sum 1M Dec64", @b sum(bigv_dec) seconds=2)
total("FPD sum 1M FD{Int64,2}", @b sum(bigv_fd) seconds=2)
total("Float64 sum 1M", @b sum(bigv_f) seconds=2)

println("\n== columnar: parse 1M strings (bulk ingestion shape) ==")
const bigstrs = repeat(STRS, 1000)
function parseall(::Type{T}, strs) where {T}
    s = zero(Int64)
    for str in strs
        v = Parsers.parse(T, str)
        s += reinterpret(Int64, v isa Decimal ? v.unscaled : Int64(0))
    end
    return s
end
total("Decimals parse 1M -> D64{2}", @b parseall(D64, bigstrs) seconds=2)
function parsefall(strs)
    s = 0.0
    for str in strs
        s += Parsers.parse(Float64, str)
    end
    return s
end
total("Parsers Float64 parse 1M", @b parsefall(bigstrs) seconds=2)
function parsedecfp(strs)
    s = zero(DecFP.Dec64)
    for str in strs
        s += Base.parse(DecFP.Dec64, str)
    end
    return s
end
total("DecFP parse 1M -> Dec64", @b parsedecfp(bigstrs) seconds=2)
