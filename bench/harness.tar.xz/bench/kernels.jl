# Rough kernel timing + allocation spot-checks (dev tool, not CI-gating).
using Decimals: Decimals as D
using Decimals: Int256, UInt256

function bench(f, args...; n=1000, reps=50)
    f(args...)
    best = Inf
    for _ in 1:reps
        t = @elapsed begin
            for _ in 1:n
                Base.donotdelete(f(args...))
            end
        end
        best = min(best, t / n)
    end
    return best * 1e9
end

u = D._fromfullbig(UInt256, big(10)^70 + 12345)
d1 = UInt256(999983)
d2 = (UInt256(1) << 130) | UInt256(7)
d4 = UInt256(1) << 250
x128 = UInt128(10)^30 + UInt128(7)
x64 = UInt64(10)^15 + UInt64(7)

wide(u, d) = D._divrem_wide(u, d)
sd(x, k, m) = D._scaledown(x, k, false, m)

println("alloc wide by1:    ", @allocated wide(u, d1))
println("alloc wide knuth2: ", @allocated wide(u, d2))
println("alloc wide knuth4: ", @allocated wide(u, d4))
println("alloc scaledown:   ", @allocated sd(u, 33, RoundNearest))

println("divrem_wide by1:    ", round(bench(wide, u, d1), digits=1), " ns")
println("divrem_wide knuth2: ", round(bench(wide, u, d2), digits=1), " ns")
println("divrem_wide knuth4: ", round(bench(wide, u, d4), digits=1), " ns")
println("scaledown u256:     ", round(bench(sd, u, 33, RoundNearest), digits=1), " ns")
println("scaledown u128:     ", round(bench(sd, x128, 13, RoundNearest), digits=1), " ns")
println("scaledown u64:      ", round(bench(sd, x64, 6, RoundNearest), digits=1), " ns")
println("divpow10 u128:      ", round(bench(D._divpow10, x128, 13), digits=1), " ns")
println("divpow10 u64:       ", round(bench(D._divpow10, x64, 6), digits=1), " ns")
println("mul256full:         ", round(bench(D._mul256full, u, d2), digits=1), " ns")
println("mul128full:         ", round(bench(D._mul128full, x128, x128), digits=1), " ns")
println("ndigits10 u256:     ", round(bench(D._ndigits10, u), digits=1), " ns")
