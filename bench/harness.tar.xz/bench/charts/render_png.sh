#!/bin/bash
# Rasterize the chart HTML in this directory to 2400x1520 PNGs with headless Chrome
# (1200x760 CSS at DPR 2). Run gen_charts.py first.
#
# --headless=new writes the screenshot and then often hangs on the way out,
# ignoring SIGALRM, so each run is supervised by a fork+kill wrapper. Success is
# therefore judged by whether a fresh PNG appeared, not by Chrome's exit status,
# which would report the hang at exit as a failure and force needless retries.
set -u
D=$(cd "$(dirname "$0")" && pwd)
CHROME=${CHROME:-/Applications/Google Chrome.app/Contents/MacOS/Google Chrome}
[ -x "$CHROME" ] || { echo "chrome not found at $CHROME (set CHROME=...)" >&2; exit 2; }
rc_all=0
for h in "$D"/*.html; do
  f=$(basename "$h" .html)
  png=$D/$f.png
  ok=0
  for attempt in 1 2 3; do
    p=$(mktemp -d)
    marker=$p/marker; : > "$marker"
    perl -e '$pid=fork; if(!$pid){exec @ARGV or die} $SIG{ALRM}=sub{kill 9,$pid; exit 9}; alarm 60; waitpid($pid,0); exit($?>>8)' \
      "$CHROME" --headless=new --disable-gpu --hide-scrollbars --no-first-run --no-default-browser-check --disable-extensions \
      --user-data-dir="$p" --force-device-scale-factor=2 --window-size=1200,760 \
      --screenshot="$png" "file://$h" >/dev/null 2>&1
    pkill -f "user-data-dir=$p" 2>/dev/null
    if [ -f "$png" ] && [ "$png" -nt "$marker" ]; then echo "$f.png"; ok=1; rm -rf "$p"; break; fi
    rm -rf "$p"
    echo "$f: attempt $attempt produced no fresh png" >&2
  done
  [ $ok -eq 1 ] || rc_all=1
done
exit $rc_all
