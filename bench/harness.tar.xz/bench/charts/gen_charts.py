#!/usr/bin/env python3
"""Decimals.jl 1.0 performance charts.

Reads the TSVs written by the harnesses in bench/results/ and writes
bench/charts/decimals-<slug>.{svg,html}. render_png.sh rasterizes the HTML.

Palette is the dataviz reference categorical palette, validated with
scripts/validate_palette.js in both light and dark mode; series order within
each chart is the order that passes the adjacent-pair gates (see PERF.md).
Every bar carries a direct value label, which is also the required relief for
the slots below 3:1 contrast on the light surface.
"""
import html
import math
import os

S = os.path.dirname(os.path.abspath(__file__))
BENCH = os.path.dirname(S)
RESULTS = os.path.join(BENCH, "results")

# ---------------------------------------------------------------- palette ---
LIGHT = dict(surface="#fcfcfb", ink="#0b0b0b", ink2="#52514e", muted="#898781",
             grid="#e1e0d9", axis="#c3c2b7")
DARK = dict(surface="#1a1a19", ink="#ffffff", ink2="#c3c2b7", muted="#898781",
            grid="#333331", axis="#4a4a46")
SERIES = {  # name -> (light, dark)
    "Decimals 1.0": ("#2a78d6", "#3987e5"),
    "Decimals 0.5.1": ("#eb6834", "#d95926"),
    "DecFP": ("#1baf7a", "#199e70"),
    "FixedPointDecimals": ("#eda100", "#c98500"),
    "rust_decimal": ("#e87ba4", "#d55181"),
    "Python decimal": ("#008300", "#008300"),
    "polars": ("#4a3aa7", "#9085e9"),
    "duckdb": ("#e34948", "#e66767"),
}
FONT = "system-ui, -apple-system, 'Segoe UI', Helvetica, Arial, sans-serif"
W, H = 1200, 760


def esc(s):
    return html.escape(str(s), quote=True)


FOOT2 = ("Apple M3 Max · macOS 24.6 · Julia 1.12.6 · Decimals 0.5.1 (registered) vs Decimals 1.0 (PR #107) · DecFP 1.4.2 · "
         "FixedPointDecimals 0.6.5 · Parsers 3.0.0 · rust_decimal 1.43 · Python 3.14.2 · polars 1.43.2 · duckdb 1.5.5")
FOOT_CHARS = 168  # footer wrap width at 11px in the 1080px text column


# ------------------------------------------------------------------- data ---
def read_tsv(name):
    rows = []
    with open(os.path.join(RESULTS, name)) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if parts[0] in ("impl", "group"):
                continue
            rows.append(parts)
    return rows


oldrows = {(r[1], r[2]): (float(r[3]), float(r[5])) for r in read_tsv("oldvsnew-old.tsv")}
newrows = {(r[1], r[2]): (float(r[3]), float(r[5])) for r in read_tsv("oldvsnew-new.tsv")}
cross = {(r[0], r[1], r[2]): float(r[3]) for r in read_tsv("crosslib.tsv")}
fpd = {(r[0], r[1], r[2]): float(r[3]) for r in read_tsv("fpd.tsv")}
rust = {(r[0], r[1], r[2]): (float(r[3]), r[4]) for r in read_tsv("rust.tsv")}
pyd = {(r[0], r[1], r[2]): float(r[3]) for r in read_tsv("py-default.tsv")}
py1t = {(r[0], r[1], r[2]): float(r[3]) for r in read_tsv("py-1t.tsv")}
mt = {(r[0], r[1], r[2]): float(r[3]) for r in read_tsv("mtbulk.tsv")}
mem = {}
for fn in ("memory-old.tsv", "memory-new.tsv"):
    for r in read_tsv(fn):
        mem[(r[0], r[1])] = float(r[2])
bulkparse = {}
for r in read_tsv("bulkparse.tsv"):
    bulkparse.setdefault(r[0], []).append(float(r[2]))
BP = {k: min(v) for k, v in bulkparse.items()}


# ------------------------------------------------------------- formatting ---
def fmt(v):
    if v == 0:
        return "0"
    a = abs(v)
    if a < 0.01:
        return f"{v:.3f}"
    if a < 10:
        return f"{v:.2f}"
    if a < 100:
        return f"{v:.1f}"
    return f"{v:,.0f}"


def fmt_ratio(r):
    if r >= 100:
        return f"{r:,.0f}×"
    if r >= 10:
        return f"{r:.0f}×"
    return f"{r:.1f}×"


def log_ticks(lo, hi):
    """Decade ticks covering [lo, hi]."""
    d0, d1 = math.floor(math.log10(lo)), math.ceil(math.log10(hi))
    return [10.0 ** d for d in range(d0, d1 + 1)]


def tick_label(v):
    if v >= 1:
        return f"{v:,.0f}"
    return f"{v:g}"


def nice_step(span, target=5):
    raw = span / target if span > 0 else 1
    mag = 10 ** math.floor(math.log10(raw))
    for m in (1, 2, 2.5, 5, 10):
        if m * mag >= raw:
            return m * mag
    return 10 * mag


# --------------------------------------------------------------- SVG shell ---
def svg_open(title, subtitle, series_names, legend_y=112):
    """Header, theme-aware CSS custom properties, title block and legend."""
    css = [":root{", ]
    for role, val in LIGHT.items():
        css.append(f"--{role}:{val};")
    for name, (lt, _) in SERIES.items():
        css.append(f"--s-{slugify(name)}:{lt};")
    css.append("}")
    css.append("@media (prefers-color-scheme: dark){:root{")
    for role, val in DARK.items():
        css.append(f"--{role}:{val};")
    for name, (_, dk) in SERIES.items():
        css.append(f"--s-{slugify(name)}:{dk};")
    css.append("}}")
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="{FONT}">',
         "<style>" + "".join(css) + "</style>",
         f'<rect width="{W}" height="{H}" fill="var(--surface)"/>',
         f'<text x="60" y="50" font-size="25" font-weight="600" fill="var(--ink)">{esc(title)}</text>',
         f'<text x="60" y="77" font-size="14.5" fill="var(--ink2)">{esc(subtitle)}</text>']
    lx = 60
    for name in series_names:
        o.append(f'<rect x="{lx}" y="{legend_y - 11}" width="13" height="13" rx="3" fill="var(--s-{slugify(name)})"/>')
        o.append(f'<text x="{lx + 20}" y="{legend_y}" font-size="13.5" fill="var(--ink2)">{esc(name)}</text>')
        lx += 20 + 7.4 * len(name) + 28
    return o


def slugify(s):
    return s.lower().replace(" ", "-").replace(".", "").replace("_", "-")


def light_vars():
    """Light palette as an inline style attribute. Set on the <svg> element itself, it
    beats the stylesheet's :root rules for every descendant, so the rasterized PNG is
    light regardless of the OS theme headless Chrome happens to inherit."""
    parts = [f"--{role}:{val}" for role, val in LIGHT.items()]
    parts += [f"--s-{slugify(name)}:{lt}" for name, (lt, _) in SERIES.items()]
    return ";".join(parts)


def wrap(text, width):
    lines, cur = [], ""
    for word in text.split():
        if cur and len(cur) + 1 + len(word) > width:
            lines.append(cur)
            cur = word
        else:
            cur = f"{cur} {word}".strip()
    if cur:
        lines.append(cur)
    return lines


def svg_close(o, foot1, slug):
    # footers are wrapped, not clipped: they carry the method and the versions, which
    # is exactly the part a skeptical reader needs to be able to read
    lines = wrap(foot1, FOOT_CHARS) + wrap(FOOT2, FOOT_CHARS)
    y = H - 16 - 15 * (len(lines) - 1)
    for ln in lines:
        o.append(f'<text x="60" y="{y}" font-size="11" fill="var(--muted)">{esc(ln)}</text>')
        y += 15
    o.append("</svg>")
    svg = "\n".join(o)
    with open(os.path.join(S, f"decimals-{slug}.svg"), "w") as f:
        f.write(svg)
    # the .svg keeps its media query and follows the reader's theme; the .html that
    # feeds the rasterizer is pinned light so the committed PNGs are deterministic
    pinned = svg.replace("<svg xmlns=", f'<svg style="{light_vars()}" xmlns=', 1)
    with open(os.path.join(S, f"decimals-{slug}.html"), "w") as f:
        f.write('<!doctype html><html><head><meta name="color-scheme" content="light light">'
                f'</head><body style="margin:0;background:{LIGHT["surface"]}">{pinned}</body></html>')
    print("wrote", slug)


def note(o, x, y, text, width=148, size=12.5, fill="var(--ink2)", lh=19):
    """Wrapped annotation block. Notes carry the exactness caveats, so they must not
    run off the canvas."""
    for ln in wrap(text, width):
        o.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}">{esc(ln)}</text>')
        y += lh
    return y


def lower_is_better(o, x, y):
    o.append(f'<text x="{x}" y="{y}" font-size="11.5" fill="var(--muted)">◀ lower is better</text>')


def bar_path(x, y, w, h, r=4):
    """Bar with rounded data-end, square against the baseline (vertical)."""
    r = max(0, min(r, h / 2, w / 2))
    return (f'M{x:.1f},{y + h:.1f} V{y + r:.1f} Q{x:.1f},{y:.1f} {x + r:.1f},{y:.1f} '
            f'H{x + w - r:.1f} Q{x + w:.1f},{y:.1f} {x + w:.1f},{y + r:.1f} V{y + h:.1f} Z')


def hbar_path(x, y, w, h, r=4):
    """Horizontal bar, rounded at the right (data) end."""
    r = max(0, min(r, h / 2, w / 2))
    return (f'M{x:.1f},{y:.1f} H{x + w - r:.1f} Q{x + w:.1f},{y:.1f} {x + w:.1f},{y + r:.1f} '
            f'V{y + h - r:.1f} Q{x + w:.1f},{y + h:.1f} {x + w - r:.1f},{y + h:.1f} H{x:.1f} Z')


# =================================================== chart 1: scalar old/new ==
SCALAR_OPS = ["parse money", "parse 18-digit", "parse 38-digit", "from Float64", "from Int",
              "add", "subtract", "multiply", "divide", "less-than", "compare to Float64",
              "equality", "hash", "string", "Float64 conversion", "round(digits=1)"]
PRETTY = {"parse money": 'parse "123456.78"', "parse 18-digit": "parse 18-digit",
          "parse 38-digit": "parse 38-digit", "from Float64": "construct from Float64",
          "from Int": "construct from Int", "add": "add  (a + b)", "subtract": "subtract  (a − b)",
          "multiply": "multiply  (a × b)", "divide": "divide  (a ÷ b)",
          "less-than": "compare  (a < b)", "compare to Float64": "compare  (a < 1.5, mixed)",
          "equality": "equality  (a == b)", "hash": "hash",
          "string": "string(x)", "Float64 conversion": "convert to Float64",
          "round(digits=1)": "round(x, digits=1)"}


def chart_scalar_oldnew():
    names = ["Decimals 0.5.1", "Decimals 1.0"]
    o = svg_open("Decimals 0.5.1 vs Decimals 1.0 — scalar operations",
                 "Nanoseconds per operation, log scale. Same operation, same 1000-value corpus, "
                 "same public API (Base.parse) on both sides.", names)
    X0, X1, Y0, Y1 = 210, 1055, 138, 636
    lo, hi = 0.05, 10000.0
    ticks = log_ticks(lo, hi)
    sx = lambda v: X0 + (math.log10(max(v, lo)) - math.log10(lo)) / (math.log10(hi) - math.log10(lo)) * (X1 - X0)
    for t in ticks:
        x = sx(t)
        o.append(f'<line x1="{x:.1f}" y1="{Y0}" x2="{x:.1f}" y2="{Y1}" stroke="var(--grid)" stroke-width="1"/>')
        o.append(f'<text x="{x:.1f}" y="{Y1 + 18}" font-size="11.5" text-anchor="middle" fill="var(--muted)">{tick_label(t)}</text>')
    o.append(f'<line x1="{X0}" y1="{Y0}" x2="{X0}" y2="{Y1}" stroke="var(--axis)" stroke-width="1"/>')
    o.append(f'<text x="{(X0 + X1) / 2:.0f}" y="{Y1 + 38}" font-size="12" text-anchor="middle" fill="var(--muted)">nanoseconds per operation (log scale)</text>')
    rowh = (Y1 - Y0) / len(SCALAR_OPS)
    bh = 11.5
    for i, op in enumerate(SCALAR_OPS):
        oldv = oldrows[("scalar", op)][0]
        newv = newrows[("scalar", op)][0]
        cy = Y0 + rowh * (i + 0.5)
        o.append(f'<text x="{X0 - 12}" y="{cy + 4:.1f}" font-size="12.5" text-anchor="end" fill="var(--ink)">{esc(PRETTY[op])}</text>')
        for j, (nm, val) in enumerate((("Decimals 0.5.1", oldv), ("Decimals 1.0", newv))):
            by = cy + (j - 1) * (bh + 2) + 1
            wpx = sx(val) - X0
            o.append(f'<path d="{hbar_path(X0, by, max(wpx, 1.5), bh)}" fill="var(--s-{slugify(nm)})"/>')
            o.append(f'<text x="{X0 + max(wpx, 1.5) + 6:.1f}" y="{by + bh - 1.5:.1f}" font-size="10.5" fill="var(--ink2)" '
                     f'style="font-variant-numeric:tabular-nums">{fmt(val)}</text>')
        o.append(f'<text x="{X1 + 62}" y="{cy + 4:.1f}" font-size="12.5" font-weight="600" text-anchor="end" '
                 f'fill="var(--ink)" style="font-variant-numeric:tabular-nums">{fmt_ratio(oldv / newv)}</text>')
    o.append(f'<text x="{X1 + 62}" y="{Y0 - 12}" font-size="11.5" font-weight="600" text-anchor="end" fill="var(--ink2)">1.0 speed-up</text>')
    lower_is_better(o, 700, 112)
    svg_close(o, "Method: Chairmarks minimum; each sample runs the operation over a seeded 1000-value corpus and divides by 1000. "
                 "Both releases share a UUID and cannot coexist, so each was measured in its own fresh environment, in its own process.", "01-scalar-old-vs-new")


# ===================================================== chart 2: bulk old/new ==
def chart_bulk_oldnew():
    names = ["Decimals 0.5.1", "Decimals 1.0"]
    o = svg_open("Decimals 0.5.1 vs Decimals 1.0 — 1,000,000-element column operations",
                 "Milliseconds for the whole 1M-element operation, log scale. Lower is better.", names)
    groups = [("parse 1M strings", BP["old"], BP["new"]),
              ("sum 1M values", oldrows[("bulk", "sum 1M")][0], newrows[("bulk", "sum 1M")][0]),
              ("sort! 1M values", oldrows[("bulk", "sort 1M")][0], newrows[("bulk", "sort 1M")][0]),
              ("maximum of 1M", oldrows[("bulk", "maximum 1M")][0], newrows[("bulk", "maximum 1M")][0])]
    X0, X1, Y0, Y1 = 110, 1140, 160, 590
    lo, hi = 0.1, 100000.0
    sy = lambda v: Y1 - (math.log10(max(v, lo)) - math.log10(lo)) / (math.log10(hi) - math.log10(lo)) * (Y1 - Y0)
    for t in log_ticks(lo, hi):
        y = sy(t)
        o.append(f'<line x1="{X0}" y1="{y:.1f}" x2="{X1}" y2="{y:.1f}" stroke="var(--grid)" stroke-width="1"/>')
        o.append(f'<text x="{X0 - 10}" y="{y + 4:.1f}" font-size="11.5" text-anchor="end" fill="var(--muted)">{tick_label(t)}</text>')
    o.append(f'<text x="{X0 - 10}" y="{Y0 - 14}" font-size="12" text-anchor="end" fill="var(--muted)">ms</text>')
    slot = (X1 - X0) / len(groups)
    bw, pitch = 76, 90
    for gi, (label, oldv, newv) in enumerate(groups):
        cx = X0 + slot * (gi + 0.5)
        for j, (nm, val) in enumerate((("Decimals 0.5.1", oldv), ("Decimals 1.0", newv))):
            bx = cx + (j - 0.5) * pitch - bw / 2
            top = sy(val)
            o.append(f'<path d="{bar_path(bx, top, bw, Y1 - top)}" fill="var(--s-{slugify(nm)})"/>')
            txt = f"{val:,.0f} ms" if val >= 1000 else (f"{val:.2f} ms" if val < 10 else f"{val:.1f} ms")
            o.append(f'<text x="{bx + bw / 2:.1f}" y="{top - 9:.1f}" font-size="13" text-anchor="middle" fill="var(--ink)" '
                     f'style="font-variant-numeric:tabular-nums">{txt}</text>')
        o.append(f'<text x="{cx:.1f}" y="{Y1 + 26}" font-size="14.5" font-weight="600" text-anchor="middle" fill="var(--ink)">{esc(label)}</text>')
        o.append(f'<text x="{cx:.1f}" y="{Y1 + 50}" font-size="13" text-anchor="middle" fill="var(--ink2)">'
                 f'1.0 is {fmt_ratio(oldv / newv)} faster</text>')
    lower_is_better(o, 1030, 112)
    svg_close(o, "Method: sum and sort! are the Chairmarks minimum over repeated samples. parse 1M is the minimum of independent "
                 "fresh-process runs (bench/bulkparse.jl) — 0.5.1's bulk parse is GC-bound, so it is timed on a pristine heap, "
                 "the measurement most favourable to 0.5.1.", "02-bulk-old-vs-new")


# ======================================================= chart 3: memory =====
def chart_memory():
    names = ["Decimals 0.5.1", "Decimals 1.0"]
    o = svg_open("Decimals 0.5.1 vs Decimals 1.0 — memory per element",
                 "Bytes per element of a 1,000,000-element decimal column. Lower is better.", names)
    groups = [("sizeof(element)", mem[("old", "sizeof(element)")], mem[("new", "sizeof(element)")],
               "what the type system stores"),
              ("Base.summarysize / element", mem[("old", "summarysize/element")], mem[("new", "summarysize/element")],
               "Julia's object-graph walk"),
              ("live heap / element", mem[("old", "live-bytes/element")], mem[("new", "live-bytes/element")],
               "GC live-bytes delta, incl. GMP buffers")]
    X0, X1, Y0, Y1 = 110, 1140, 175, 580
    ymax = 90.0
    step = 10.0
    sy = lambda v: Y1 - (v / ymax) * (Y1 - Y0)
    v = 0.0
    while v <= ymax + 1e-9:
        y = sy(v)
        o.append(f'<line x1="{X0}" y1="{y:.1f}" x2="{X1}" y2="{y:.1f}" stroke="{"var(--axis)" if v == 0 else "var(--grid)"}" stroke-width="1"/>')
        o.append(f'<text x="{X0 - 10}" y="{y + 4:.1f}" font-size="11.5" text-anchor="end" fill="var(--muted)">{v:.0f}</text>')
        v += step
    o.append(f'<text x="{X0 - 10}" y="{Y0 - 14}" font-size="12" text-anchor="end" fill="var(--muted)">bytes</text>')
    slot = (X1 - X0) / len(groups)
    bw, pitch = 76, 90
    for gi, (label, oldv, newv, sub) in enumerate(groups):
        cx = X0 + slot * (gi + 0.5)
        for j, (nm, val) in enumerate((("Decimals 0.5.1", oldv), ("Decimals 1.0", newv))):
            bx = cx + (j - 0.5) * pitch - bw / 2
            top = sy(val)
            o.append(f'<path d="{bar_path(bx, top, bw, Y1 - top)}" fill="var(--s-{slugify(nm)})"/>')
            o.append(f'<text x="{bx + bw / 2:.1f}" y="{top - 9:.1f}" font-size="13" text-anchor="middle" fill="var(--ink)" '
                     f'style="font-variant-numeric:tabular-nums">{val:.1f} B</text>')
        o.append(f'<text x="{cx:.1f}" y="{Y1 + 26}" font-size="14" font-weight="600" text-anchor="middle" fill="var(--ink)">{esc(label)}</text>')
        o.append(f'<text x="{cx:.1f}" y="{Y1 + 45}" font-size="11.5" text-anchor="middle" fill="var(--muted)">{esc(sub)}</text>')
        o.append(f'<text x="{cx:.1f}" y="{Y1 + 66}" font-size="13" text-anchor="middle" fill="var(--ink2)">'
                 f'{fmt_ratio(oldv / newv)} smaller</text>')
    note(o, X0, Y0 - 44,
         "Decimals 1.0 is an isbits 8-byte value, so a 1M column is one 8 MB array; 0.5.1 is a boxed struct holding a BigInt, "
         "so the same column is 1M separate heap objects.")
    lower_is_better(o, 1030, 112)
    svg_close(o, "Method: bench/memory.jl. summarysize walks the reachable object graph; the live-heap figure is the GC live-bytes "
                 "delta across building the column and does include GMP limb buffers, which summarysize misses.", "03-memory-old-vs-new")


# ============================================ chart 4: scalar vs other libs ===
LIB_ORDER = ["Decimals 1.0", "DecFP", "FixedPointDecimals", "rust_decimal", "Python decimal"]
PANEL_OPS = [("parse", 'parse "123456.78"'), ("format to String", "format to String"),
             ("add", "add  (a + b) — 1000-element fold"), ("multiply", "multiply  (a × b)"),
             ("divide", "divide  (a ÷ b)"), ("hash", "hash"),
             ("Float64 conversion", "convert to Float64 — map over 1000")]
# ops whose fold/map shape vectorizes for an unchecked library: the panel
# also shows the single-call cost, where checked and unchecked are equal
CALL_NOTE_OPS = {"add", "Float64 conversion"}


def call_value(lib, op):
    if lib == "Decimals 1.0":
        return cross.get(("call", "Decimals 1.0", op))
    if lib == "DecFP":
        return cross.get(("call", "DecFP Dec64", op))
    if lib == "FixedPointDecimals":
        return fpd.get(("call", "FixedPointDecimals", op))
    return None


def scalar_value(lib, op):
    if lib == "Decimals 1.0":
        return cross.get(("scalar", "Decimals 1.0", op))
    if lib == "DecFP":
        return cross.get(("scalar", "DecFP Dec64", op))
    if lib == "FixedPointDecimals":
        return fpd.get(("scalar", "FixedPointDecimals", op))
    if lib == "rust_decimal":
        r = rust.get(("scalar", "rust_decimal", op))
        return r[0] if r else None
    if lib == "Python decimal":
        return pyd.get(("scalar", "Python decimal", op))
    return None


def chart_scalar_libs():
    o = svg_open("Decimals 1.0 vs other decimal libraries — scalar operations",
                 "Nanoseconds per operation. One linear axis per operation (small multiples), because the operations "
                 "differ in cost by three orders of magnitude.", LIB_ORDER)
    cols, rows = 4, 2
    PX0, PY0 = 62, 158
    pw, ph = 278, 228
    gapx, gapy = 4, 40
    for pi, (op, title) in enumerate(PANEL_OPS):
        c, r = pi % cols, pi // cols
        x0 = PX0 + c * (pw + gapx)
        y0 = PY0 + r * (ph + gapy)
        vals = [(lib, scalar_value(lib, op)) for lib in LIB_ORDER]
        vals = [(l, v) for l, v in vals if v is not None]
        # the axis is set by the compiled libraries; Python decimal is one to
        # two orders of magnitude slower and would flatten every other bar, so
        # its bar is clipped at the top with a break mark and keeps its label
        vmax = max(v for l, v in vals if l != "Python decimal")
        step = nice_step(vmax * 1.15, 3)
        ymax = step * math.ceil(vmax * 1.15 / step)
        ax0, ax1 = x0 + 46, x0 + pw - 8
        ay0, ay1 = y0 + 30, y0 + ph - 46
        sy = lambda v: ay1 - (v / ymax) * (ay1 - ay0)
        o.append(f'<text x="{x0 + 4}" y="{y0 + 14}" font-size="13.5" font-weight="600" fill="var(--ink)">{esc(title)}</text>')
        if op in CALL_NOTE_OPS:
            calls = [(l, call_value(l, op)) for l in ("Decimals 1.0", "FixedPointDecimals", "DecFP")]
            calls = [(l, v) for l, v in calls if v is not None]
            if calls:
                short = {"Decimals 1.0": "Decimals", "FixedPointDecimals": "FPD", "DecFP": "DecFP"}
                callnote = "single call: " + " · ".join(f"{short[l]} {fmt(v)}" for l, v in calls)
                o.append(f'<text x="{x0 + 4}" y="{y0 + ph - 30}" font-size="10.5" fill="var(--ink2)" '
                         f'style="font-variant-numeric:tabular-nums">{esc(callnote)}</text>')
        t = 0.0
        while t <= ymax + 1e-9:
            y = sy(t)
            o.append(f'<line x1="{ax0}" y1="{y:.1f}" x2="{ax1}" y2="{y:.1f}" stroke="{"var(--axis)" if t == 0 else "var(--grid)"}" stroke-width="1"/>')
            o.append(f'<text x="{ax0 - 7}" y="{y + 4:.1f}" font-size="10.5" text-anchor="end" fill="var(--muted)">{tick_label(t) if t >= 1 or t == 0 else f"{t:g}"}</text>')
            t += step
        n = len(vals)
        slot = (ax1 - ax0) / n
        bw = min(38, slot - 10)
        for i, (lib, val) in enumerate(vals):
            cx = ax0 + slot * (i + 0.5)
            clipped = val > ymax
            top = ay0 if clipped else sy(val)
            o.append(f'<path d="{bar_path(cx - bw / 2, top, bw, ay1 - top, 3)}" fill="var(--s-{slugify(lib)})"/>')
            if clipped:
                # break mark: two short slanted strokes across the bar near its top
                yb = ay0 + 14
                o.append(f'<path d="M{cx - bw / 2 - 3},{yb + 3} L{cx + bw / 2 + 3},{yb - 3} M{cx - bw / 2 - 3},{yb + 8} '
                         f'L{cx + bw / 2 + 3},{yb + 2}" stroke="var(--surface)" stroke-width="3" fill="none"/>')
            o.append(f'<text x="{cx:.1f}" y="{top - 6:.1f}" font-size="10.5" text-anchor="middle" fill="var(--ink2)" '
                     f'style="font-variant-numeric:tabular-nums">{fmt(val)}{"▲" if clipped else ""}</text>')
    o.append(f'<text x="{PX0 + 3 * (pw + gapx) + 6}" y="{PY0 + ph + gapy + 48}" font-size="12.5" fill="var(--ink2)">'
             'Money-shaped values.</text>')
    o.append(f'<text x="{PX0 + 3 * (pw + gapx) + 6}" y="{PY0 + ph + gapy + 68}" font-size="12" fill="var(--muted)">'
             'Decimals = Decimal64{2},</text>')
    o.append(f'<text x="{PX0 + 3 * (pw + gapx) + 6}" y="{PY0 + ph + gapy + 85}" font-size="12" fill="var(--muted)">'
             'DecFP = Dec64,</text>')
    o.append(f'<text x="{PX0 + 3 * (pw + gapx) + 6}" y="{PY0 + ph + gapy + 102}" font-size="12" fill="var(--muted)">'
             'FPD = FixedDecimal{Int64,2}.</text>')
    o.append(f'<text x="{PX0 + 3 * (pw + gapx) + 6}" y="{PY0 + ph + gapy + 126}" font-size="12" fill="var(--muted)">'
             'rust_decimal and Python have</text>')
    o.append(f'<text x="{PX0 + 3 * (pw + gapx) + 6}" y="{PY0 + ph + gapy + 143}" font-size="12" fill="var(--muted)">'
             'no comparable hash op.</text>')
    o.append(f'<text x="{PX0 + 3 * (pw + gapx) + 6}" y="{PY0 + ph + gapy + 167}" font-size="12" fill="var(--muted)">'
             '▲ bar clipped: axis set by the</text>')
    o.append(f'<text x="{PX0 + 3 * (pw + gapx) + 6}" y="{PY0 + ph + gapy + 184}" font-size="12" fill="var(--muted)">'
             'compiled libraries; label is exact.</text>')
    lower_is_better(o, 1030, 112)
    svg_close(o, "Method: Julia via Chairmarks minimum over a 1000-value corpus; rust_decimal best-of-200 loops over the same corpus "
                 "(--release, lto). Python best-of-7 perf_counter_ns. Decimals parses via Parsers.parse; every other library uses its only "
                 "parse entry point. add/multiply/divide are folds and Float64 conversion a map, so each figure includes one loop iteration; an unchecked "
                 "add and an unconditional divide let those loops vectorize, which is what the FPD add/Float64 bars show — the single-call line "
                 "in those two panels is the non-vectorized cost.", "04-scalar-vs-libraries")


# ================================================= chart 5: bulk vs engines ===
def chart_bulk_engines():
    names = ["Decimals 1.0", "rust_decimal", "polars", "duckdb"]
    o = svg_open("Decimals 1.0 vs columnar engines — 1,000,000-element parse and sum",
                 "Milliseconds for the whole 1M-element operation. Left column: everything on one thread. "
                 "Right column: each engine at its own default parallelism.", names)
    panels = [
        ("parse 1M strings → decimal", "single-threaded",
         [("Decimals 1.0", mt[("bulk", "Decimals 1.0 1T", "parse 1M")]),
          ("rust_decimal", rust[("bulk", "rust_decimal", "parse 1M")][0]),
          ("polars", py1t[("bulk", "polars 1T", "parse 1M")]),
          ("duckdb", py1t[("bulk", "duckdb 1T", "parse 1M")])]),
        ("parse 1M strings → decimal", "default parallelism",
         [("Decimals 1.0", mt[("bulk", "Decimals 1.0 10T", "parse 1M")]),
          ("polars", pyd[("bulk", "polars", "parse 1M")]),
          ("duckdb", pyd[("bulk", "duckdb", "parse 1M")])]),
        ("sum 1M decimal values", "single-threaded",
         [("Decimals 1.0", mt[("bulk", "Decimals 1.0 1T", "sum 1M")]),
          ("rust_decimal", rust[("bulk", "rust_decimal", "sum 1M")][0]),
          ("polars", py1t[("bulk", "polars 1T", "sum 1M")]),
          ("duckdb", py1t[("bulk", "duckdb 1T", "sum 1M")])]),
        ("sum 1M decimal values", "default parallelism",
         [("Decimals 1.0", mt[("bulk", "Decimals 1.0 10T", "sum 1M")]),
          ("polars", pyd[("bulk", "polars", "sum 1M")]),
          ("duckdb", pyd[("bulk", "duckdb", "sum 1M")])]),
    ]
    cols = 2
    PX0, PY0 = 90, 168
    pw, ph = 520, 208
    gapx, gapy = 60, 62
    for pi, (title, sub, vals) in enumerate(panels):
        c, r = pi % cols, pi // cols
        x0 = PX0 + c * (pw + gapx)
        y0 = PY0 + r * (ph + gapy)
        vmax = max(v for _, v in vals)
        step = nice_step(vmax * 1.2, 4)
        ymax = step * math.ceil(vmax * 1.2 / step)
        ax0, ax1 = x0 + 54, x0 + pw - 10
        ay0, ay1 = y0 + 44, y0 + ph - 30   # ay0 clears the panel subtitle
        sy = lambda v: ay1 - (v / ymax) * (ay1 - ay0)
        o.append(f'<text x="{x0}" y="{y0 + 8}" font-size="14" font-weight="600" fill="var(--ink)">{esc(title)}</text>')
        o.append(f'<text x="{x0}" y="{y0 + 26}" font-size="12.5" fill="var(--ink2)">{esc(sub)}</text>')
        t = 0.0
        while t <= ymax + 1e-9:
            y = sy(t)
            o.append(f'<line x1="{ax0}" y1="{y:.1f}" x2="{ax1}" y2="{y:.1f}" stroke="{"var(--axis)" if t == 0 else "var(--grid)"}" stroke-width="1"/>')
            lbl = f"{t:,.0f}" if step >= 1 else f"{t:g}"
            o.append(f'<text x="{ax0 - 8}" y="{y + 4:.1f}" font-size="11" text-anchor="end" fill="var(--muted)">{lbl}</text>')
            t += step
        n = len(vals)
        slot = (ax1 - ax0) / n
        bw = min(86, slot - 26)
        for i, (lib, val) in enumerate(vals):
            cx = ax0 + slot * (i + 0.5)
            top = sy(val)
            o.append(f'<path d="{bar_path(cx - bw / 2, top, bw, ay1 - top)}" fill="var(--s-{slugify(lib)})"/>')
            o.append(f'<text x="{cx:.1f}" y="{top - 8:.1f}" font-size="12.5" text-anchor="middle" fill="var(--ink)" '
                     f'style="font-variant-numeric:tabular-nums">{val:.3f}</text>' if val < 1 else
                     f'<text x="{cx:.1f}" y="{top - 8:.1f}" font-size="12.5" text-anchor="middle" fill="var(--ink)" '
                     f'style="font-variant-numeric:tabular-nums">{val:.2f}</text>')
            o.append(f'<text x="{cx:.1f}" y="{ay1 + 18:.1f}" font-size="11.5" text-anchor="middle" fill="var(--ink2)">{esc(lib)}</text>')
    lower_is_better(o, 1030, 112)
    svg_close(o, "Method: Julia via Chairmarks minimum (bench/mtbulk.jl; 10 threads = julia -t auto on this machine); polars and duckdb "
                 "best-of-5/7 wall clock, pinned with POLARS_MAX_THREADS=1 / duckdb threads=1 for the single-threaded column; "
                 "rust_decimal best-of-20 (single-threaded only). Same 1M strings for every engine.", "05-bulk-vs-engines")


# ============================================== chart 6: parse by digit width =
BAND_ORDER = ["1-4 digits", "5-9 digits", "10-18 digits", "19-38 digits", "39-76 digits"]
BAND_SERIES = ["DecFP", "Decimals 1.0", "rust_decimal"]


def chart_bands():
    o = svg_open("Parse latency by input width — Decimals 1.0 vs DecFP vs rust_decimal",
                 "Nanoseconds to parse one value, by the number of significant digits in the input.", BAND_SERIES)
    X0, X1, Y0, Y1 = 110, 1140, 172, 566
    vals = {}
    for b in BAND_ORDER:
        vals[("Decimals 1.0", b)] = cross[("bands", "Decimals 1.0", b)]
        vals[("DecFP", b)] = cross.get(("bands", "DecFP Dec64", b)) or cross[("bands", "DecFP Dec128", b)]
        rv = rust.get(("bands", "rust_decimal", b))
        vals[("rust_decimal", b)] = rv[0] if rv and rv[1] == "ns/op" else None
    vmax = max(v for v in vals.values() if v is not None)
    step = nice_step(vmax * 1.15, 5)
    ymax = step * math.ceil(vmax * 1.15 / step)
    sy = lambda v: Y1 - (v / ymax) * (Y1 - Y0)
    t = 0.0
    while t <= ymax + 1e-9:
        y = sy(t)
        o.append(f'<line x1="{X0}" y1="{y:.1f}" x2="{X1}" y2="{y:.1f}" stroke="{"var(--axis)" if t == 0 else "var(--grid)"}" stroke-width="1"/>')
        o.append(f'<text x="{X0 - 10}" y="{y + 4:.1f}" font-size="11.5" text-anchor="end" fill="var(--muted)">{t:,.0f}</text>')
        t += step
    o.append(f'<text x="{X0 - 10}" y="{Y0 - 14}" font-size="12" text-anchor="end" fill="var(--muted)">ns</text>')
    slot = (X1 - X0) / len(BAND_ORDER)
    bw, pitch = 52, 60
    STORAGE = {"1-4 digits": "Int64 / Dec64 / i96", "5-9 digits": "Int64 / Dec64 / i96",
               "10-18 digits": "Int64 / Dec128 / i96", "19-38 digits": "Int128 / Dec128 / —",
               "39-76 digits": "Int256 / Dec128 / —"}
    for gi, band in enumerate(BAND_ORDER):
        cx = X0 + slot * (gi + 0.5)
        for si, lib in enumerate(BAND_SERIES):
            bx = cx + (si - 1) * pitch - bw / 2
            val = vals[(lib, band)]
            if val is None:
                o.append(f'<rect x="{bx}" y="{Y1 - 44}" width="{bw}" height="44" fill="none" stroke="var(--axis)" '
                         f'stroke-width="1.5" stroke-dasharray="4 3" rx="4"/>')
                o.append(f'<text x="{bx + bw / 2:.1f}" y="{Y1 - 26:.1f}" font-size="10" text-anchor="middle" fill="var(--muted)">not</text>')
                o.append(f'<text x="{bx + bw / 2:.1f}" y="{Y1 - 14:.1f}" font-size="10" text-anchor="middle" fill="var(--muted)">exact</text>')
                continue
            top = sy(val)
            o.append(f'<path d="{bar_path(bx, top, bw, Y1 - top)}" fill="var(--s-{slugify(lib)})"/>')
            o.append(f'<text x="{bx + bw / 2:.1f}" y="{top - 8:.1f}" font-size="12" text-anchor="middle" fill="var(--ink)" '
                     f'style="font-variant-numeric:tabular-nums">{val:.1f}</text>')
        o.append(f'<text x="{cx:.1f}" y="{Y1 + 26}" font-size="14" font-weight="600" text-anchor="middle" fill="var(--ink)">{esc(band)}</text>')
        o.append(f'<text x="{cx:.1f}" y="{Y1 + 45}" font-size="11" text-anchor="middle" fill="var(--muted)">{esc(STORAGE[band])}</text>')
    note(o, X0, Y1 + 78,
         "Exactness differs, and the chart does not hide it: Decimals is exact in every band. DecFP Dec128 carries 34 significant "
         "digits, so in the 39–76 band it is rounding — Decimals matches its speed while staying exact. rust_decimal has a 96-bit "
         "mantissa (~28 digits); above that it cannot represent the input at all, so those bars are absent rather than fast.")
    lower_is_better(o, 1030, 112)
    svg_close(o, "Method: Chairmarks / best-of-200 minimum over a seeded 1000-value corpus per band, digit counts drawn uniformly "
                 "from the band. Decimals uses the narrowest storage that holds the band; DecFP uses Dec64 up to 9 digits and Dec128 above "
                 "(Dec64 holds only 16 significant digits).", "06-parse-by-digit-width")


for f in (chart_scalar_oldnew, chart_bulk_oldnew, chart_memory, chart_scalar_libs, chart_bulk_engines, chart_bands):
    f()
