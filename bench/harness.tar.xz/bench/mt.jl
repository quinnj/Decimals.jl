# Multithreaded columnar sum/parse on a synthetic corpus — run with `julia -t auto`.
# Engines (polars/duckdb) parallelize by default, so this is the side that makes
# a default-parallelism comparison apples-to-apples. The reported numbers in
# bench/PERF.md come from bench/mtbulk.jl, which uses the committed corpora;
# this script is the quicker ad-hoc probe.
using Chairmarks, Printf, Random
using Decimals, Parsers
using Decimals: Int256, UInt256

rng = Xoshiro(11000)
const N = 1_000_000
println("julia threads: ", Threads.nthreads())

const vals = [reinterpret(Decimal64{2}, rand(rng, -10^15:10^15)) for _ in 1:N]
const strs = [string(rand(rng, -99999999:99999999) / 100) for _ in 1:1000]
const bigstrs = repeat(strs, 1000)

function mtsum(v, nch)
    n = length(v)
    chunk = cld(n, nch)
    parts = Vector{Decimal{38,2,Int128}}(undef, nch)
    Threads.@threads for c in 1:nch
        lo = (c - 1) * chunk + 1
        hi = min(c * chunk, n)
        parts[c] = lo <= hi ? sum(view(v, lo:hi)) : zero(Decimal{38,2,Int128})
    end
    return sum(parts)
end

function mtparse(strs, nch)
    n = length(strs)
    chunk = cld(n, nch)
    out = Vector{Decimal64{2}}(undef, n)
    Threads.@threads for c in 1:nch
        lo = (c - 1) * chunk + 1
        hi = min(c * chunk, n)
        for i in lo:hi
            @inbounds out[i] = Parsers.parse(Decimal64{2}, strs[i])
        end
    end
    return out
end

@assert mtsum(vals, Threads.nthreads()) == sum(vals)
nt = Threads.nthreads()
@printf("sum 1M   1T: %7.3f ms   %dT: %7.3f ms\n",
        1e3 * (@b sum(vals) seconds=2).time,
        nt, 1e3 * (@b mtsum(vals, nt) seconds=2).time)
@printf("parse 1M 1T: %7.3f ms   %dT: %7.3f ms\n",
        1e3 * (@b mtparse(bigstrs, 1) seconds=2).time,
        nt, 1e3 * (@b mtparse(bigstrs, nt) seconds=2).time)
println("(engine references at default parallelism: bench/results/py-default.tsv)")
